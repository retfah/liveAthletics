// stores the list of the childs in each file
// TODO: this file could be created automatically by scanning the views folder and getting all the injected names

// index:      [string], name of the file including the filetype
// childs:     [string], mandatory all names of the childs in this page; used e.g. to be able to 'render' the page with empty childs, as it is necessary to deliver the language-pre-rendered pages for preloading on the client

module.exports = {
    "root.ejs": {
        childs: ["child1", "title", "pages", "pageName"]
    },
    "configuration.ejs": {
        childs: ["child2"]
    },
    "configurationSelf.ejs": {
        childs: ["inj"]
    },
    "athletes.ejs": {
        childs: []
    },
    "adminServer.ejs": {
        childs: []
    }
}