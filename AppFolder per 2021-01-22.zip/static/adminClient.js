// this is the implementation for the admin room on the client

const roomServer = require('./roomServer');

class rMeetings extends roomServer{