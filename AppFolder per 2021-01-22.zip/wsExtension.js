
/** Change log:
 * 2019-09-15:	started some changes in the request-response function: receiveing the request and receiving the response is acknowledged now. The first prevents resending of the request, if it is already 'processing' (from te viewpoint of the wsExtension; it might also 'hang' on another stack). The response-acknowledgement is massively extended. Options allow to select between different levels of acknowledgement (from no ack to regular to paranoid modes.) Failure and success callback are introduced also on the server, to report when the response could not be sent. (TODO: this could be implemented with async too, but this is not supported yet in all browsers and so we stick to callbacks. It would actually probably be possible that the wsExtension provides callback and async, and the mathod beeing run on the server would not need to be the same.) see also Notes from 2019-09-15 and important additional notes from TODO-Date about the different ack levels. 
 * 
 */

// MAIN TODO: 
// - error handling: what happens if the connection is closed before everything was sent? --> we need something as is implemented for the pages, where there is a list of 
// - the syn-ack stuff might be important if there is no feedback whether or not the message could be sent. With ws in node, the information about whether it could be sent is available. But on the client? If it is not available there, we must care about, what happens if anote/request message does not arrive respectively if it is not acknowledged. For requests, at least the sending is retried until acknowledgement and thus for requests a more complex implementation (acknowledging the arrival of the request and the response) is not absolutely needed, given the software basing on it is able to handle the case of missing acknowledgement. 
// - REMOVE all syn/ack differentiation: Websockets run on TCP; that means, we do not need the syn/ack stuff, as it is guaranteed that the messages do arrive, as long as there is a connection (Yes, but what if it fails during sending?)
// the implementation shall be such that we assume a non-reliably Websocket connectoin, meaning that when we send data, we do not rely on a feedback of the Websocket-implementation whether the data has arrived or not (as this is not available in some implementations), but we wait on our own feedback from the wsExtension of teh partner. 


// this file shall contain all stuff needed for the framwwork that extends the basic websocket-capabilities with syn/ack notes and requests. Thus this fraework is one layer above ws
// The same code shall be runnable on the client and the server

// rooms are actually one layer above, since entering a room and leaving it are simple requests (with hopefully response true)

/** --- TODO ---- 
 * - some stuff written to the stacks is actually never needed again --> dont store this for perfomance reasons.
 * - many things are not hacking safe; e.g. calls on the stack with fake stamps that do not exist as indices
 * - think about: what happens, if an ack does not arrive? make sure the 're-sent' syn does not result in a second execution of something.
 * - 
*/

/**
 * Error Codes:
 * // TODO: recheck the codes!
 * 1-10: reserved for errors in the connection :
 * 1, request: no response until timeout, neither an ack nor the response
 * 2, request: no response until timeout, but ack received
 * 3, request: connection lost before an ack (for the request) arrived. The request might get processed anyway!
 * 4, request: connection lost before the response arrived, but the request was acknowledged
 * 5, request: timeout after response received, but before execution
 * 6, request: connection lost after response received, but before execution
 * 7, request: request certainly not processed, as ack before executionAckCount did not even arrive.
 * 1, request (status): number of interval reached, after response execution, before last ack
 * 2, request (status): connection lost, after response execution, before last ack
 * 1, noteAck: no answer during all the attempts, but the connection is running. The server might still be working on the request, but the request is closed now anyway. That means, if the answer arrives later, it will not be processed anymore! TODO: should we implement another system, where the requesting function can decide, whether it want to wait furtehr or to delete the reqreust ffrom the stack?
 * 2, request, noteAck: no response until the connection was lost. (independent on the number of attempts made until the loss of connection)
 * 11-...: error codes for stuff running over the websocket-connection through the wsExtension
 *   rooms: 
 * 	   11-20: error codes for internal server errors (e.g. if a function returns non-correct objects)
 * 	   21-: error codes for in-function errors, specifically for each function; e.g. when the data cannot be processed
 */

/**
 * INFORMATION ABOUT THE CALLBACKS:
 * 
When is which callback called?:
- in the sendRequest on the caller (in general client):
  - successCB: as soon as the opt.executeAckCount, defined by the responder (server) (!), is reached and thus the response can be executed
  - failureCB: whenever an error occurs (connection or during processing on the server; can be differentiated by the errCode)
  - statusCB: whenever ANY response/ack/whatever arrives. The caller must differentiate at what state the . 
  - opt.executeAckCount (defined by the caller/client): has no influence on when (after how many acks) the successCB on itself is executed
  - successCB: (response) =>{}
  - failureCB: (errMsg, errCode, status, lastIncomingAckCount) => {}
  - statusCB: (status, lastIncomingAckCount) => {} 
    - status: 
	  1 = request sent, but execution on responder was not yet started
	  2 = request sent and responder (server) might have started to process the request
	  3 = responder (server) has started to process the request (i.e. at least one ack after opt.executeAckCount has arrived on the caller)
	  4 = response received, not started to process (because of opt.executeAckCount sent from responder (server))
	  5 = response recieved, started to process (or starts now)
  
- when sending the response on the responder/server:
  - there is no successCB, as it is not clear, when success is reached: when the responder sends the ack that will start the execution on the caller/client (or the response itself when executeAckCount=0) and this message is not acknowledged (e.g. because of an interruption in the connection before an ack could be received), the responder/server does not know whether the client has received the execution request. (The same problem appears during sending of the request on the client.) However, the function on the responder/server that has processed the request can decide by itself when success is reached by listening to the statusCB, where the status even indicates the current state. Apart of that there is the failureCB, called whenever the connection fails. 
  - statusCB wird bei jedem eintreffenden Ack ausgelöst. Die übergebene Funktion muss selber filtern, auf welche Ack's es reagieren soll. 
  - statusCB: (status, lastIncomingAckCount)=>{}
    - status:
	  11 = response sent, but execution on caller (client) was not yet started
	  12 = response sent and caller (client) might have started to process the response
	  13 = caller (client) has started to process the response (i.e. at least one ack after opt.executeAckCount has arrived on the responder)
  - failureCB only on connection error or on timeout
  - failureCB: (errMsg, errCode, status, lastIncomingAckCount) => {}

 */


/**
 * The class extending the basic ws connection with four different types of data trasfer: notes with/without acknowledgements and request/response with/without acknowledgement
 * NOTE: currently, when this class is used, a global logger-object called logger must exist! --> change this in the long run
 */
//wsExtensionClass: class wsExtensionClass {
	module.exports  = class wsExtensionClass{

		/**
		 * 
		 * @param {function} sendingFunc The function to be called for sending a message with the only parameter beeing the message.
		 * @param {function} incomingNoteFunc The function called when a note arrives. One parameter: the note. TODO: probably some info about the wsConnection / the webSocket-Partner is needed too and should be part of a second parameter.
		 * @param {function} incomingRequestFunc The function called when a request arrives. Two parameters: the request, the function to respond. The function to respond takes one argeument: the reponce. TODO: probably some info about the wsConnection / the webSocket-Partner is needed too and should be part of a second parameter.
		 * @param {logger} logger The logger instance
		 * @param {function} cbTest A function that is called on every incoming request and that is given the complete message. Intended only for testing and used here to simulate a busy server (i.e. a slow responding server). The only property given is the parsed message. The message is then used 
		 */
		constructor(sendingFunc, incomingNoteFunc, incomingRequestFunc, logger, cbTest=(message)=>{}){
			// the constructor initializes everything (e.g. stacks) after the connection has been established
			this.stackNoteAck = {}; // stack for acknowledged notes
			this.stackRequest = {}; // stack for non-acknowledged requests
			this.stackIncomingRequest = {}; // stack for incoming requests; used until last response-ack sent (i.e. not only for the request itself)
			//this.stackRequestAck = {}; // stack for acknowledged requests
			this.sendingFunc = sendingFunc; // the function that has to be called for sending messages; the wsExtension class will call the sendingFunc with one argument: the message
			this.logger = logger;
			this.cbTest = cbTest;

			//this.stack = {}; // the general stack for everything that needs to be on the stack 
	
			// a variable to be set to true as soon as the connection is getting or is closed. It serves the purpose that the instance of this wsExtension knows when it has no sense anymore to retry to send something. 
			this.closing = false;

			// add functions to which the messages are passed to; they will be called with one or two arguments: (1): the message, (2): the function to be called to send the response (for request/response only; the argument is the message to be sent)
	
			// TODO: probably it would make sense that requests are automatically answered with an error when an error occurs on the server, such that a client does not need to wait and retry several times, as processing the request will likely fail over and over again. 
			this.incomingNoteFunc = incomingNoteFunc;
			this.incomingRequestFunc = incomingRequestFunc;
			// ... other such functions
		}

		/**
		 * Function to be called when the ws-connection is closing/closed
		 */
		close(){
			this.closing = true;

			// TODO 'empty' (=call failure callbacks) all stacks, call the failure callbacks with 
		}
	
		/**
		 * sendError: send an error message back to the client
		 * @param {string} error The error message to be sent 
		 */
		sendError(error){
			var mess = {};
			mess.type = "error";
			mess.data = error;
			let messStr = JSON.stringify(mess);
			this.logger.log(99, `Error sent per ws: ${messStr}` )
			this.sendingFunc(messStr);
		}
	
		/**
		 * sendNote:	send a normal note that does not get acknowledged. It is tried to send the note once. When it gets lost, nobody cares.
		 * @param {string} note The note to be sent. 
		 */
		sendNote (note){
			// prepare
			var mess = {};
			mess.type = "note";
			mess.stamp = this.uuidv4();
			mess.data = note;
			
			// send
			let messStr = JSON.stringify(mess);
			this.logger.log(99, `Note sent per ws: ${messStr}` )
			this.sendingFunc(messStr);
		}
	
		/**
		 * sendNoteAck: send a note with acknwoledgement to B. On success (=message recieved by B and on ws-extended-level successfully parsed), the success callback is executed, failure otherwise. The difference to 'request' is that success for a request includes the processing on the partner and it returns 'success' only if the processing on the partner was succeeful while here success is already sent when the note was handles over to the requective funciton on the server.
		 * @param {string / binary} message The message to be sent as string or binary. 
		 * @param {callback} success A callback with parameters TODO.
		 * @param {callback} failure A callback with two self explanatory parameters: code (int) and message (string)
		 * @param {object} opt Object storing parameters for the transmission.:
		 * @param {integer} opt.retryNumber How many times sending should be retried (default = 5 --> 6 attempts)
		 * @param {integer} opt.retryInterval How many milliseconds sending should be retried (default = 1000ms)
		 */
		sendNoteAck (note, success=()=>{}, failure=(errCode, errMsg)=>{}, opt={}){
			var uuid = this.uuidv4(); // get the unique ID for this transmission
			// prepare message to be sent
			var mess = {}
			mess.type = "noteSyn"; // will be answered with noteAck, if everything goes as expected
			mess.stamp = uuid;
			mess.data = note;
			let messString = JSON.stringify(mess);
	
			// create everything needed on the server
			let stackObj = {}
			stackObj.cbSuccess = success;
			stackObj.cbFailure = failure;
			stackObj.message = messString;
			opt.retryNumber = opt.retryNumber || 5; // how many times to retry sending, when no ack has arrived yet; 
			opt.retryAttempts = 0; // no retry yet; this number is increased with every retry until retrynumber is reached --> then the failure-callback is executed	
			opt.retryInterval = opt.retryInterval || 1000; // in ms
			stackObj.opt = opt;
			this.stackNoteAck[uuid] = stackObj;
			// make sure we can access the "this" in the anonymous function
			var self = this;
			// send again if needed; if the acknowledgement already arrived, the interval is stopped by the Ack-arrival and is not executed anymore.
			opt.interval = setInterval(()=>{
				if (stackObj.opt.retryAttempts==stackObj.opt.retryNumber){
					this.logger.log(99, "The following message could not be sent: " + stackObj.message) // write message to log. Only in debugging-mode, as in general the sending function should decide to log or not in the failure callback
					stackObj.cbFailure("Failed to send message within " + (stackObj.opt.retryAttempts+1) + " attempts.", 1) // failure callback
					
					clearInterval(stackObj.opt.interval); // stop the interval
					delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
				} else { 
					// some more attempts to do --> send the message again if there is still a connection

					if (this.closing){
						this.logger.log(99, "The following message could not be sent: " + stackObj.message) // write message to log. Only in debugging-mode, as in general the sending function should decide to log or not in the failure callback
						stackObj.cbFailure("Failed to send message within " + (stackObj.opt.retryAttempts+1) + " attempts because the connection was closed before all attempts were made.", 2) // failure callback
						clearInterval(stackObj.opt.interval); // stop the interval
						delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
					} else {
						stackObj.opt.retryAttempts += 1;
						self.sendingFunc(stackObj.message);
					}
				}
			},opt.retryInterval)
			
			// send the message
			this.logger.log(99, `NoteAck sent per ws: ${messString}` )
			this.sendingFunc(messString);
		}
	
		/**
		 * sendRequest: send a request. wait for an answer for some seconds, repeat the request then if no answer has arrived for a few times and finally either call success on success or failure on failure
		 * @param {string / object / binary} message The message to be sent as string or binary. 
		 * @param {callback} success A callback with the response as parameter.
		 * @param {callback} failure A callback with four parameters: errorMessage (string), errorCode (int), status (int), lastIncomingAckCount (int)
		 * @param {object} opt Object storing parameters for the transmission.:
		 * @param {integer} opt.retryNumber How many times sending should be retried (default = 0 --> 1 attempts)
		 * @param {integer} opt.retryInterval How many milliseconds sending should be retried (default = 1000ms)
		 * @param {integer} opt.maxTime How long (milliseconds!) it will be waited at max until the request is deemded failed (and the failure CB is called). (After the response has arrived and has started processing, the timeout is stopped. A failure with sending/receiving an ack after that leads to a call of the status CB.)
		 * @param {integer} opt.ackTotal how many acks are sent. Eventually additional variables for the count, after how many acks the data should be processed
		 * @param {integer} opt.executeAckCount After which # of acks the request is executed. Must be an even number. (default = 0) 
		 * note: for executeResponse the other end can decide.
		 * @param {callback} status=(status, lastIncomingAckCount)=>{} called whenever a message (response or ack) arrives. For status codes see the additional information at the beginning of the file 
		 */
		sendRequest (request, success=(response)=>{}, failure=(errMsg, errCode, status, lastIncomingAckCount)=>{}, opt={}, status=(status, lastIncomingAckCount)=>{}){

			// initialize the options of the request
			opt.retryNumber = opt.retryNumber || 0; // how many times to retry sending, when no ack has arrived yet; 
			opt.retryAttempts = 0; // no retry yet; this number is increased with every retry until retrynumber is reached --> then the failure-callback is executed	
			opt.retryInterval = opt.retryInterval || 1000; // in ms
			opt.executeAckCount = opt.executeAckCount || 0; // by default directly execute a request
			opt.ackTotal = Math.max(opt.ackTotal, opt.executeAckCount) || Math.max(Math.min(1, opt.retryNumber), opt.executeAckCount); // 
			
			// if there is no status object, we do not need to ask for an ack--> wrong. We might want to have an status for the response, but not for sending.
			// but we do not need an ack, when retryNumber=0

			// the failureTime includes all the possible retrys:
			opt.failureTime = (opt.maxTime || 3000); 


			var uuid = this.uuidv4(); // get the unique ID for this transmission
			// prepare message to be sent
			let mess = {};
			mess.type = "request"; // will be answered with noteAck, if everything goes as expected
			mess.stamp = uuid;
			mess.executeAckCount = opt.executeAckCount;
			mess.ackCount = 0; // the first sending is no ack, obviously
			mess.ackTotal = opt.ackTotal;
			mess.data = request;
			mess.retryNumber = opt.retryNumber;
			mess.retryInterval = opt.retryInterval;
			
			let messString = JSON.stringify(mess);

			// create the object for the stack: stores everything needed/defined in this message
			let stackObj = {};
			stackObj.cbSuccess = success;
			stackObj.cbFailure = failure;
			stackObj.cbStatus = status;
			stackObj.message = messString; 
			stackObj.ackCount = 0;
			stackObj.stamp = uuid;

			// calculate the current status
			if (opt.executeAckCount==0){
				stackObj.status = 2;
			} else {
				stackObj.status = 1;
			}
			
			stackObj.opt = opt;

			// add to stack
			this.stackRequest[uuid] = stackObj;

			var self = this;
			
			if (opt.ackTotal>=1 && opt.retryNumber>0){
				// start the interval for resending the request, if the request-ack has not arrived yet. Store the interval-handle to be able to stop it as soon as the request-ack has arrived.
				opt.interval = setInterval(()=>{

					this.logger.log(50, `The following request was not acknowledged within ${opt.retryAttempts+1} attempts in the interval of ${opt.retryInterval}ms : ` + stackObj.message)

					if (stackObj.opt.retryAttempts==stackObj.opt.retryNumber){
						clearInterval(stackObj.opt.interval); // stop the interval
						delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
						// do not call the failure callback, since this will be done within the timeout 
					} else { // some more attempts to do --> send the request again
						if (this.closing){
							
							this.logger.log(50, `connection lost. Cannot send the following request anymore: ${stackObj.message}`);

							stackObj.cbFailure("Failed to send request within " + (stackObj.opt.retryAttempts+1) + " attempts, because the connection was closed before all attempts were made.", 2, stackObj.status, stackObj.ackCount) // failure callback
							clearInterval(stackObj.opt.interval); // stop the interval 
							delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
							clearTimeout(stackObj.opt.timeout); // stop the timeout

							// delete the object from the stack
							delete this.stackRequest[stackObj.stamp];

						} else {
							stackObj.opt.retryAttempts += 1;
							self.sendingFunc(stackObj.message);
						}
					}
				}, opt.retryInterval)
			}

			// start the timeout until which the response must have arrived or otherwise the failureCB is raised
			opt.timeout = setTimeout(()=>{
				this.logger.log(50, `The following request timed out and is now considered failed: ${stackObj.message}`);

				stackObj.cbFailure(`The following request timed out and is now considered failed: ${stackObj.message}`, 2, stackObj.status, stackObj.ackCount) // failure callback

				delete this.stackRequest[stackObj.stamp];

			}, opt.failureTime)

			
			// finally, send the request
			this.logger.log(99, `Request sent per ws: ${messString}` )
			this.sendingFunc(messString);
		}
	
		/**
		 * sendRequestAck: send a request with  acknowledgements for each way.
		 * opt must allow to set how many answers are expected before closing the event and rainsing an error if not all were answered. This can be important if the partner has multiple functions listening to the same request and all of them will send some data back. 
		 * @param {string / object / binary} message The message to be sent as string or binary. 
		 * @param {callback} success A callback with the response and the counter as parameter. The counter indicates the number of the response that arrived (might be importnat for requests with multiple responses).
		 * @param {callback} failure A callback with two self explanatory parameters: code (int) and message (string)
		 * @param {object} opt Object storing parameters for the transmission.:
		 * @param {integer} opt.retryNumber How many times sending should be retried (default = 5 --> 6 attempts)
		 * @param {integer} opt.retryInterval How many milliseconds sending should be retried (default = 1000ms)
		 * @param {integer} opt.answerNumber How many answers are expected (default=1). Setting it to zero allows to wait for infinite responses or until a response has the flag 'lastResponse'. Attention: not ending many requests might lead to problems if the stack grows too much!
		 * @param {integer} opt.answerTimeoutFirst How many milliseconds to wait at max for the responses after request-ack did arrive
		 * @param {integer} opt.answerTimeoutInterval How many milliseconds to wait at max for the next response to arrive, after the first did arrive
		 */
		//@param {integer} opt.answerTimeoutLast How many milliseonds to wait for the last response, after the request-ack --> not implemented yet
		/*sendRequestAck (request, success=(response, counter)=>{}, failure=(errCode, errMsg)=>{}, opt={}){
			// get the unique ID for this transmission
			var uuid = this.uuidv4(); 

			// prepare message to be sent
			let mess = {};
			mess.type = "requestSyn"; // will be answered with noteAck, if everything goes as expected
			mess.stamp = uuid;
			mess.data = request;

			let messString = JSON.stringify(mess);

			// create the object for the stack: stores everything needed/defined in this message
			let stackObj = {};
			stackObj.cbSuccess = success;
			stackObj.cbFailure = failure;
			stackObj.message = messString; 

			// initialize the options of the request
			opt.retryNumber = opt.retryNumber || 5; // how many times to retry sending, when no ack has arrived yet; 
			opt.retryAttempts = 0; // no retry yet; this number is increased with every retry until retrynumber is reached --> then the failure-callback is executed	
			opt.retryInterval = opt.retryInterval || 1000; // in ms
			opt.answerNumber = opt.answerNumber || 1; // how many answers are expected; 0 = infinite
			opt.answerTimeoutFirst = opt.answerTimeoutFirst || 5000; // how long to wait after request-ack for the first response
			opt.answerTimeoutInterval = opt.answerTimeoutInterval || 5000; // how long to wait after each response 
			opt.state = 1;  // state: 	1 = request-syn sent
							//			2 = request-ack arrived
							// 			3 = response-syn arrived, response ack sent?

							// when to close the request, without waiting for an answer
							// what to do when a response arrives that is not on te stack (anymore) (e.g. when the response ack did not arrive or the request was closed as the answer took too long to arrive)
			stackObj.opt = opt;

			// add to stack
			this.stackRequestAck[uuid] = stackObj;

			var self = this;
			// TODO: continue here!
			// start the interval of checking if the response has arrived already. Store the interval-handle to be able to stop it as soon as the reqponce has arrived.
/*			opt.interval = setInterval(()=>{

				if (stackObj.opt.retryAttempts==stackObj.opt.retryNumber){
					this.logger.log(99, "The following message could not be sent: " + stackObj.message) // write message to log. Only in debugging-mode, as in general the sending function should decide to log or not in the failure callback
					stackObj.cbFailure("Failed to send message within " + stackObj.opt.retryAttempts + " attempts.",1) // failure callback
					clearInterval(stackObj.opt.interval); // stop the interval
											delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
				} else { // some more attempts to do --> send the message again
					stackObj.opt.retryAttempts += 1;
					self.sendingFunc(stackObj.message);
				}
			}, opt.retryInterval)*/
			/*
			// finally, send the request
			this.sendingFunc(messString);

		}*/
	
	
		/**
		 * uuidv4: Creates a unique ID according to RFC 4122, version 4. Credits go to: https://stackoverflow.com/questions/105034/create-guid-uuid-in-javascript#2117523
		 * This id shall be used for stamps.
		 */
		uuidv4() {
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
					var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
					return v.toString(16);
			});
		}
	
	
		// the function that processes the incoming messages;
		// with that kind of class structure, onMessage has automatically also access to the stackNoteAck and stuff
		_onMessage(messageRaw){
	
			// - there are different types of messages that are handled differently
			//  - note: 'one way'; A sends B a message and does not expect an immidiate reqponse on that message
			//  - request: 'two way'; A sends B a request for some data and B answers it directly
			// - there are two possibilities requests and messages:
			//  - with acknowledgement
			//  - without acknowledgement
			// - note is 1/2 way and requests are 2/4 way (without/with acknowledgement)
			// - all messages must have a unique identifier that is valid for the whole note/request (including the Acks and response): RFC 4122 UUID version 4 is used.
			// - thus, the following message types must exist
			//           Note without Acknowledegemnt
			//  - note: note without acknowledgement; A sends B something and dont care what B does with it 
			//           Note with acknowledgement
			//  - noteSyn: A sends B a note and B has to acknowledge having received the note with noteAck; B does not report what it does with the note and whether it could be processed on a higher layer (it certainly could be processed on websocket-layer, as otherwise it could not acknowledge it)
			//  - noteAck: B acknowledges having received a note from A 
			//           Request without acknowledgement (probably not needed since RequestAck is better)
			//  - Request:  A sends B a request, B processes the request and sends it back to A (response)
			//  - response: B sends A the requested data
			//           Request with Acknowledgement
			//  - RequestSyn: A sends B a request and wants acknowledgement (RequestAck)
			//  - RequestAck: B acknowledges having received the request from A and will start processing it and then send it back with reponceSyn 
			//  - responseSyn: B sends the requested data back to A and awaits the acknowledgement of A having received it
			//  - responseAck: A acknowledges having received the response
			//           General
			//  - Error: if anything goes wrong when B processes the websocket-layer --> simply send A an error and the identifier 
			//  - TODO: Room-stuff
			//
			// ACK should not be sent before the message was succefully processed on the ws-layer
	
			// Note: noteSyn, RequestSyn, ResponceSyn: all of them require having a system that sends the syn, awaits for ack and sends the syn again if the ack is not received with a certain maount of time. This system is always the same --> TODO: find a way how this can be done with only one function!
	
			//  -  the server probably needs to have a list of requests that are currently processed in order to drop the same request if the client sends it again, when it did not receive the requestAck
			//
			// --> the acknowledgements shall be handled with closures (to know what to do when it arrives or does not arrive). Additionally a list of all open requests
			// - custom ping/pong messages could be implemented in the future, when needed. The Websocket protocol itself knows some kind of ping/pong, but which cannot be handled/accessed/controlled by the user. So, a custom implementation would be on top of that as a normal note. 
			// - access / leaving groups (internally uses note with ack)
			// - broadcasts in group (currently not form the client!)
			// - broadcast overall (currently not from the cleint!)
			// - ...
	
			/* 
			every message should have:
			- type: note, noteSyn, noteAck, request, response, requestSyn, requestAck, responseSyn, responseAck, ...
			- stamp: a unique hash
			- 
			- a response must have a unique identifier too to be able to count the different responses
			[[[- eventName: the name of the event that shall be called at the partner. It can be empty too. All functions listening to that event are called one after the other. ATTENTION: It must be possible to define some events that allow only one function listening. This can be very important for ]]]
			*/
	
	
	
	
			// GEDANKEN: 
			/*
			- eventuell macht es Sinn, die Unterscheidung nach eventName auf eine weitere Schicht nach unten zu delegieren, da dies nicht direkt mit der ganzen Syn/Ack geschichte zu tun hat
	
			*/
	
	
	
			// notes: 
			// - one Event is not one room, so it is not reasonable to use the events itself and simply create an event as a room
			// - can a room be an event? maybe yes. So a room would be a normal event. This room would listen to all possible events for that room and simply spread the event to the other clients --> could work, except that then also the sending client recieves the event again...
			// - we dont need events on the server, just rooms?!? The server could either be called explicitly based on the event raised or he also subscribes to that room. 
			// - how does the note/request system work together woth the rooms/events? Do we treat all messages and requests the same and simply hand them over to the events? Or do we need special types for the room stuff and for the other stuff? --> actually the rooms belong to the websocket-stuff, as it is kind of a broadcast.
	
			// the solution is: (normally in our use, where the server has to act:) no message from a client should automatically be sent to any other clients, but the server should do that. (If for example a faked result a client sends to the server, the server must process the result and realize that it is wrong and thus NOT send thie result to the other clients!) If there is need to broadcast from clients, a dummy function on the server can be defined that does exactly this. but for the liveResults/Athleteica functionality this should not be needed. In Socket.IO it is also not possible to emit to rooms from the clients. 
	
			// events could be cascaded: events can have parents that are cllaed too: e.g. a client adds a result in the event xy, so every client showing this event must get the information, but also the general event for new/changed results in any event must be called (e.g. for live Results)
	
			// messageRaw should be a json object:
			
			this.logger.log(99, "Message recieved per ws: " + messageRaw); // can a  class access a global object
	
			var message = {}
			try{
				message = JSON.parse(messageRaw); 
			}catch(error){
				// TODO
				// send Error to client
	
			}
			if (!('type' in message)) {
				// the websocket request cannot be parsed without type and thus is simply dropped
				this.logger.log(7, 'The message "' + messageRaw + '" has no "type"-property and thus is deleted/dropped.')
				return;
			}

			// for testing: call the test-callback that will implement 'sleeping functions to test all the different failure possibilities and whether the respective callbacks are called
			// we must stop execution when a connection error shall be simulated, which is done by cbTest with returning true
			if (this.cbTest(message)){
				return;
			}
	
			// switch / case would be nice here and exists in JS; but it requires the unhandy use of "break;"" at the end of every case in order not to go though all the rest, so dont use it!
			var self = this;
			var messagetypes = {
				note: ()=>{

					// process the message
					self.incomingNoteFunc(message.data);
				},
				noteSyn: ()=>{ 
					// process the message (make sure we did not already receive it!) and respond with noteAck
					let respond = {};
					respond.type = "noteAck";
					respond.stamp = self.uuidv4();
					respond.synStamp = message.stamp;
					// no respond.data here...
	
					// acknowledge receiving the message
					self.sendingFunc(JSON.stringify(respond));
					
					// process the message
					self.incomingNoteFunc(message.data);
				},
				noteAck: ()=>{
					// check validity
					if (!message.synStamp){
						self.sendError("noteAck is not valid without synStamp!");
					} else {

						if (message.synStamp in self.stackNoteAck){

							// call the success-callback
							self.stackNoteAck[message.synStamp].cbSuccess();

							// stop the interval and delete the open MessSyn-element in the queue
							clearInterval(self.stackNoteAck[message.synStamp].opt.interval);
							delete self.stackNoteAck[message.synStamp];

						} else {
							self.logger.log(3, 'Stamp was not on stack. This happens when 1) (unlikely) somebody tries to hack you or 2) (likely) the server was very busy and could not send you an answer within you default waiting time so you sent the requst again and the server finally also processed every request (n-1 times for nothing...) or 3) (little likely) two responses were sent for the same request and thus the request was already removed from the stack. It is not allowed to have more than one response (currently) and thus the now received (second or later) response is unhandled/deleted.')
						}
					}
				},

				// request sent to system B (and also the following acks, if applicable)
				request: ()=> {

					// check that the request has a data and a stamp property.
					if ((message.data!=undefined) && (message.stamp!=undefined) && (message.ackCount!=undefined)){

						// do everythign with the stackObj and check for problems:
						let stackObj = {};
						// check if the same request (and ackCount) already arrived before --> then do not process it, otherwise add it to the stack and start processing
						if (message.stamp in self.stackIncomingRequest){

							// get the stackObj
							stackObj = self.stackIncomingRequest[message.stamp];

							// check if it is an old, already processed ack:
							if (stackObj.ackCount>= message.ackCount){
								// do not process it, just do nothing
								this.logger.log(50, 'wsExtension: Recieved request with ackCount < than the currently processed ack. The request is ignored.');
								return;
							} else if (stackObj.message){ // check that response has not been sent yet (stackObj.message exists)! otherwise just do nothing!
								// do not process it, just do nothing
								this.logger.log(50, 'wsExtension: Recieved request where the response has already been sent. The request is ignored.');
								return;
							}
							
						} else if (message.ackCount==0){
							// get values that are not resent in the following acks and that are needed anyway
							stackObj.opt = {};
							stackObj.opt.retryNumber = message.retryNumber || 0;
							stackObj.opt.retryInterval = message.retryInterval || 1000; // ms
							stackObj.opt.executeAckCount = message.executeAckCount;
							stackObj.stamp = message.stamp;
							stackObj.opt.ackTotal = message.ackTotal; 
							self.stackIncomingRequest[message.stamp] = stackObj;
							
							// store the data to the local stack-obj
							stackObj.data = message.data;

						}else {
							this.logger.log(50, 'wsExtension: Recieved message with ackCount >0, but the stamp was not yet on the stack.');
							return
						}

						// store the ack number of the last incoming message (either the request itself or an ack)
						stackObj.ackCount = message.ackCount; 

						// there is no statusCb to be called here

						// do send ack, if requested:

						// if there was an interval of sending ack's started, stop it now
						if (stackObj.opt.interval) {
							// stop the interval
							clearInterval(stackObj.opt.interval);
							delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
						}

						// first of all, if required, acknowledge having received the request, so that the request is not sent any further time
						if (message.ackCount < stackObj.opt.ackTotal) {

							// send the next ack:
							let ack = {
								type: 'requestAck',
								stamp: message.stamp,
								ackCount : message.ackCount +1 
							};
							let messageString = JSON.stringify(ack);
							self.sendingFunc(messageString);
							stackObj.obj.lastSentAck = messageString;
							
							// if this (just sent) ack will also be ack'ed and retry is wanted: start interval for resending, if no ack arrived within the interval time 
							if (stackObj.opt.retryNumber > 0 && message.ackCount < stackObj.opt.ackTotal-1) {

								// initialize retryAttempts
								stackObj.opt.retryAttempts = 0;

								stackobj.opt.interval = setInterval(()=>{
									this.logger.log(50, `wsExtension: The ack number ${message.ackCount+1} for the incoming request ${stackObj.stamp} was not acknowledged within ${stackObj.opt.retryAttempts+1} attempts in the interval of ${stackObj.opt.retryInterval}ms.`);
	

									if (stackObj.opt.retryAttempts==stackObj.opt.retryNumber){
										// no further retry attempt

										clearInterval(stackObj.opt.interval); // stop the interval
										delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
										// there is no failure callback to call. 
										
										// if the request is already executed, do nothing; if it is not yet executed, delete the request from the stack
										if (message.ackCount < stackObj.opt.executeAckCount) {
											delete self.stackIncomingRequest[message.stamp];
										}
									
										
									} else { // some more attempts to do --> send the request again
										if (self.closing){
											
											self.logger.log(50, `wsExtension: Connection lost. Ack number ${message.ackCount+1} for the incoming request ${stackObj.stamp} was not acknowledged before the conection was closed.`);
											clearInterval(stackObj.opt.interval); // stop the interval 
											delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running

											// if the request is already executed, do nothing; if it is not yet executed, delete the request from the stack
											if (message.ackCount < stackObj.opt.executeAckCount) {
												delete self.stackIncomingRequest[message.stamp];
											}
											
										} else {
											stackObj.opt.retryAttempts += 1;
											self.sendingFunc(stackObj.opt.lastSentAck);
										}
									}
								}, stackObj.opt.retryInterval);
							}

						}


						// ---------------------------------
						// start processing (if applicable):
						// TODO later: important: the support for the callbacks (success, failure, status?). 

						if (stackObj.opt.executeAckCount == message.ackCount){
							// execute the request
							// if the failurecode=0, everything is normal
							// if there was an error, the failurecode is the respective code and the response is the error-message as string.
							// create the response-funciton
							
							/**
							 * opt has the same options as in sendRequest
							 * Note: by default the data is directly executed on the client, but of course it could be overriden. However, consider the difference between a response of successful and failure during processing: while there mght be cases where the server wants to know that the client started processing the response, in by far most cases the server does not care anymore if on the server the request has failed anyway.  
							 * @param {*} response 
							 * @param {*} failureCode 
							 * @param {*} failure 
							 * @param {*} opt 
							 * @param {*} status 
							 */
							let responseFunc = (response, failureCode=0, failure=(errMsg, errCode, status, lastIncomingAckCount)=>{}, opt={}, status=(status, lastIncomingAckCount)=>{})=>{

								// mostly copied from sendRequest:

								// first, if there is an interval running, i.e. the ack-rally of the request is still going on, end it, since now the response arrives!
								if (stackObj.opt.interval){
									clearInterval(stackObj.opt.interval); // stop the interval 
									delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
								} 

								// as the old interval was stopped and as we check at incoming requests that we do not do anything when a response is already sent, we can now simply overwrite the (probably) existing stackObj.opt object, as we do not need the old anymore 

								// initialize the options of the request
								opt.retryNumber = opt.retryNumber || 0; // how many times to retry sending, when no ack has arrived yet; 
								opt.retryAttempts = 0; // no retry yet; this number is increased with every retry until retrynumber is reached --> then the failure-callback is executed	
								opt.retryInterval = opt.retryInterval || 1000; // in ms
								opt.executeAckCount = opt.executeAckCount || 0; // by default directly execute a request
								opt.ackTotal = Math.max(opt.ackTotal, opt.executeAckCount) || Math.max(Math.min(1, opt.retryNumber), opt.executeAckCount); // 

								// the failureTime includes all the possible retrys:
								opt.failureTime = (opt.maxTime || 1000); 

								// prepare message to be sent
								let mess = {};
								mess.type = "response"; // will be answered with noteAck, if everything goes as expected
								mess.stamp = stackObj.stamp;
								mess.executeAckCount = opt.executeAckCount;
								mess.ackCount = 0; // the first sending is no ack, obviously
								mess.ackTotal = opt.ackTotal;
								mess.data = response;
								mess.retryNumber = opt.retryNumber;
								mess.retryInterval = opt.retryInterval;
								mess.failureCode = failureCode;
								
								let messString = JSON.stringify(mess);

								// the stackobj already exists, but gets some new properties
								stackObj.cbFailure = failure;
								stackObj.cbStatus = status;
								stackObj.message = messString; 
								stackObj.ackCount = 0;

								// calculate the current status
								if (opt.executeAckCount==0){
									stackObj.status = 12; 
								} else {
									stackObj.status = 11; 
								}

								stackObj.opt = opt;

								// 'self' should already exist
								
								if (opt.ackTotal>=1){
									
									if (opt.retryNumber>0){
										// start the interval for resending the request, if the request-ack has not arrived yet. Store the interval-handle to be able to stop it as soon as the request-ack has arrived. The interval is stopped by the ack
										opt.interval = setInterval(()=>{

											this.logger.log(50, `The following response was not acknowledged within ${opt.retryAttempts+1} attempts in the interval of ${opt.retryInterval}ms : ` + stackObj.message)

											if (stackObj.opt.retryAttempts==stackObj.opt.retryNumber){
												clearInterval(stackObj.opt.interval); // stop the interval
												delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
												// do not call the failure callback, since this will be done within the timeout 
											} else { // some more attempts to do --> send the request again
												if (this.closing){
													
													this.logger.log(50, `connection lost. Cannot send the following response anymore: ${stackObj.message}`);

													// We do not know if the data has arrived --> call the failure callback
													stackObj.cbFailure("Failed to send response within " + (stackObj.opt.retryAttempts+1) + " attempts, because the connection was closed before all attempts were made.", 2, stackObj.status, stackObj.ackCount) // failure callback

													clearInterval(stackObj.opt.interval); // stop the interval 
													delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
													clearTimeout(stackObj.opt.timeout); // stop the timeout

													// delete the object from the stack
													delete this.stackRequest[stackObj.stamp];

												} else {
													stackObj.opt.retryAttempts += 1;
													self.sendingFunc(stackObj.message);
												}
											}
										}, opt.retryInterval)
									}
									

									// the timeout is only required when there will arrive an ack, so it is inside the interval stuff

									// start the timeout until which the response must have arrived or otherwise the failureCB is raised
									opt.timeout = setTimeout(()=>{
										this.logger.log(50, `The following response timed out and is now considered failed: ${stackObj.message}`);

										stackObj.cbFailure(`The following response timed out and is now considered failed: ${stackObj.message}`, 2, stackObj.status, stackObj.ackCount) // failure callback
		
										// delete the object from the stack
										delete this.stackRequest[stackObj.stamp];

									}, opt.failureTime)



								}


								// finally, send the request
								this.sendingFunc(messString);

							};

							// process the request
							self.incomingRequestFunc(message.data, responseFunc);

						}

					} else {
						self.sendError("request is not valid without stamp, data and ackCount properties!");
					}

				}, // end of request

				// acks sent to system A (the one that emmitted the request) during the request
				requestAck: ()=>{
					// acknowledgement, that the request has arrived on the server

					// the ack received should look like this
					/*let ack = {
						type: 'requestAck',
						stamp: message.stamp,
						ackCount : message.ackCount +1 
					};*/

					if (!('type' in message && 'stamp' in message && 'ackCount' in message)){
						// the ack cannot be processed
						self.logger.log(50, `wsExtension: Could not process requestAck because not all necessary properties were set: ${message}`);
						return;
					}

					// find the request on the stack here
					let stackObj;
					if (stackObj = self.stackRequest[message.stamp]){

						// check if it is an old, already processed ack:
						if (stackObj.ackCount>= message.ackCount){
							// do not process it, just do nothing
							this.logger.log(50, 'wsExtension: Recieved requestAck with ackCount < than the currently processed ack. The requestAck is ignored.');
							return;
						} else if (stackObj.data){ // check that response did not arrive yet! otherwise just do nothing as this could interfere with the incoming response, since the opt and ackCount properties now refer to the incoming response!
							this.logger.log(50, 'wsExtension: Recieved requestAck where the response has already arrived. The request is ignored.');
							return;
						}

						// set the current ackCount
						stackObj.ackCount = message.ackCount;

						// calculate the current status:
						if (stackObj.opt.executeAckCount < stackObj.ackCount){
							// we know that execution was started
							stackObj.status = 3;
						} else if (stackObj.opt.executeAckCount == 1 + stackObj.ackCount){
							// after the ack sent now, execution will be started
							stackObj.status = 2;
						}

						// call the statusCB:
						stackObj.cbStatus(stackObj.status, stackObj.ackCount);

						// if there was an interval of sending ack's started, stop it now
						if (stackObj.opt.interval) {
							// stop the interval
							clearInterval(stackObj.opt.interval);
							delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
						}

						// if needed send new ack; with interval, if needed.
						// first of all, if required, acknowledge having received the request, so that the request is not sent any further time
						if (message.ackCount<stackObj.opt.ackTotal) {
							
							// send the ack:
							let ack = {
								type: 'request',
								stamp: message.stamp,
								ackCount: message.ackCount +1
							}
							let mess = JSON.stringify(ack);
							self.sendingFunc(mess);
							stackObj.opt.lastSentAck = mess;

							// start interval, if needed:
							// if this (just sent) ack will also be ack'ed and retry is wanted: start interval for resending, if no ack arrived within the interval time 
							if (stackObj.opt.retryNumber > 0 && message.ackCount < stackObj.opt.ackTotal-1) {

								// initialize retryAttempts
								stackObj.opt.retryAttempts = 0;

								stackobj.opt.interval = setInterval(()=>{
									this.logger.log(50, `wsExtension: The ack number ${message.ackCount+1} for the incoming requestAck ${stackObj.stamp} was not acknowledged within ${stackObj.opt.retryAttempts+1} attempts in the interval of ${stackObj.opt.retryInterval}ms.`);

									if (stackObj.opt.retryAttempts==stackObj.opt.retryNumber){
										// no further retry attempt

										clearInterval(stackObj.opt.interval); // stop the interval
										delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
										
										// if the request is already executed, do nothing; if it is not yet executed, call failure and delete the request from the stack
										if (message.ackCount<message.executeAckCount) {
											self.stackRequest[message.stamp].cbFailure(`The ack number ${message.ackCount+1} for the incoming requestAck ${stackObj.stamp} was not acknowledged within ${stackObj.opt.retryAttempts+1} attempts in the interval of ${stackObj.opt.retryInterval}ms. `, 7, stackObj.status, stackObj.ackCount); 
											delete self.stackRequest[message.stamp];
										}
									
										
									} else { // some more attempts to do --> send the request again
										if (self.closing){
											
											self.logger.log(50, `wsExtension: Connection lost. Ack number ${message.ackCount+1} for the incoming requestAck ${stackObj.stamp} was not acknowledged before the conection was closed.`);
											clearInterval(stackObj.opt.interval); // stop the interval 
											delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running

											// if the request is already executed, do nothing; if it is not yet executed, delete the request from the stack
											if (message.ackCount<message.executeAckCount) {
												self.stackRequest[message.stamp].cbFailure(`Connection lost. Ack number ${message.ackCount+1} for the incoming requestAck ${stackObj.stamp} was not acknowledged before the conection was closed.`, 7, stackObj.status, stackObj.ackCount); 
												delete self.stackRequest[message.stamp];
											}
											
										} else {
											stackObj.opt.retryAttempts += 1;
											self.sendingFunc(stackObj.opt.lastSentAck);
										}
									}
								}, stackObj.opt.retryInterval);
							}


						}

					} else {
						// the ack cannot be processed
						self.logger.log(50, `wsExtension: Could not process requestAck because it is not on the stack: ${message}`);
						return;
					}
					
				},

				// response sent to system A (the one that emmitted the request), (and also the following acks, if applicable) 
				response: ()=> {
					// a response to a request is received, process it and finally delete the request from the stack

					// TODO: Adapt from request: mostly the callbacks, stacks 

					// check that the request has a data and a stamp property.
					if ((message.data!=undefined) && (message.stamp!=undefined) && (message.ackCount!=undefined)){

						// the stackObj should obviously already exist
						let stackObj;
						if (stackObj = self.stackRequest[message.stamp]){

							if (message.ackCount==0){
								// check that we did not recieve a reponse with ack=0 before (i.e. when data exists)
								if(stackObj.data){
									// do not process it, just do nothing
									this.logger.log(50, 'wsExtension: Recieved response with ackCount==0 that already arrived before. The response is ignored.');
									return;
								}

								// if there was an interval of sending ack's started, stop it now
								// Note: cannot be done outside these if-conditionals, since we reset the stackObj.opt object here and so the reference to old inteverals would get lost.
								if (stackObj.opt.interval) {
									// stop the interval
									clearInterval(stackObj.opt.interval);
									delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
								}

								// get values that are not resent in the following acks and that are needed anyway
								// do NOT delete the whole opt object, as e.g. opt.timeout must be kept!
								stackObj.opt.retryNumber = message.retryNumber || 0;
								stackObj.opt.retryInterval = message.retryInterval || 1000; // ms
								stackObj.opt.executeAckCount = message.executeAckCount;
								//stackObj.stamp = message.stamp;
								stackObj.opt.ackTotal = message.ackTotal; 
								
								// store the data and the failureCode to the local stack-obj
								stackObj.data = message.data;
								stackObj.failureCode = message.failureCode;

							}
							// check if it is an old, already processed ack:
							else if (stackObj.ackCount>= message.ackCount){
								// do not process it, just do nothing
								this.logger.log(50, 'wsExtension: Recieved request with ackCount < than the currently processed ack. The request is ignored.');
								return;
							
							// here if it is a normal ack:
							} else {
								// if there was an interval of sending ack's started, stop it now
								if (stackObj.opt.interval) {
									// stop the interval
									clearInterval(stackObj.opt.interval);
									delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
								}
							}

							// so, here we either recieved the data or an ack. But the further processing is independent of it


							// store the ack number of the last incoming message (this also resets the count when the first response is coming after the requests)
							stackObj.ackCount = message.ackCount;

							// calculate the current status:
							if (stackObj.opt.executeAckCount == stackObj.ackCount){
								// the execution will start now
								stackObj.status = 5;
							} else {
								// the exection will start at a later ack
								stackObj.status = 4;
							}

							// call the statusCB:
							stackObj.cbStatus(stackObj.status, stackObj.ackCount);

							// first of all, if required, acknowledge having received the request, so that the response is not sent any further time
							if (message.ackCount < stackObj.opt.ackTotal) {

								// send the next ack:
								let ack = {
									type: 'responseAck',
									stamp: message.stamp,
									ackCount : message.ackCount +1 
								};
								let messageString = JSON.stringify(ack);
								self.sendingFunc(messageString);
								stackObj.obj.lastSentAck = messageString;
								
								// if this (just sent) ack will also be ack'ed and retry is wanted: start interval for resending, if no ack arrived within the interval time 
								if (stackObj.opt.retryNumber > 0 && message.ackCount < stackObj.opt.ackTotal-1) {

									// initialize retryAttempts
									stackObj.opt.retryAttempts = 0;

									stackobj.opt.interval = setInterval(()=>{
										this.logger.log(50, `wsExtension: The ack number ${message.ackCount+1} for the incoming response ${stackObj.stamp} was not acknowledged within ${stackObj.opt.retryAttempts+1} attempts in the interval of ${stackObj.opt.retryInterval}ms.`);
		
										// Important note:
										// do we really need to differentiate between 'the connection is closing' and 'simply not getting an ack-answer' yet? Or do we always get the ack, when there is a connection and so the other case never happens? No: not getting an ack but the connection is still open can happen, i.e. when the server is currently too busy to answer --> when the connection is lost, delete the timeout and call cbFailure, otherwise keep the timeout and do not call failure (as this is not considered a failure; we still wait for an answer as the last ack is still on a stack waiting for execution)

										if (stackObj.opt.retryAttempts==stackObj.opt.retryNumber){
											// no further retry attempt

											clearInterval(stackObj.opt.interval); // stop the interval
											delete stackObj.opt.interval; // delete it, as we use the presence of the interval to know whether an interval is running
											// there is no callback to call. 
											
										} else { // some more attempts to do --> send the request again if there is a connection
											if (self.closing){
												
												self.logger.log(50, `wsExtension: Connection lost. Ack number ${message.ackCount+1} for the incoming response ${stackObj.stamp} was not acknowledged before the conection was closed.`);

												stackObj.cbFailure(`The ack ${stackObj.ackCount+1} could not be sent since the connection is lost and the response data was not yet processed.`, 6, stackObj.status, stackObj.ackCount)												

												clearInterval(stackObj.opt.interval); // stop the interval 
												delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running

												clearTimeout(stackObj.opt.timeout); // stop the timeout
												
												delete self.stackRequest[message.stamp];
												
											} else {
												stackObj.opt.retryAttempts += 1;
												self.sendingFunc(stackObj.opt.lastSentAck);
											}
										}
									}, stackObj.opt.retryInterval);
								}

							} // end acknowledging


							// ---------------------------------
							// start processing (if applicable):

							if (stackObj.opt.executeAckCount == message.ackCount){
								// process the response

								// if the failurecode=0, everything is normal
								// if there was an error, the failurecode is the respective code and the response is the error-message as string.

								if (message.failureCode){ // failurecode is the statusCode; 0=no failure and the success-callback is called
									// call the failure callback
									stackObj.cbFailure(stackObj.data, stackObj.failureCode, stackObj.status, stackObj.ackCount);
								}else{
									// call success callback
									stackObj.cbSuccess(stackObj.data);
								}

							}

							// if this was the last call on this stackObj, then stop the timeout and delete it from the stack
							if (stackObj.ackCount >= stackObj.opt.ackTotal-1) {
								clearTimeout(stackObj.opt.timeout);
								delete this.stackRequest[stackObj.stamp];
							}

						} else {
							// the ack cannot be processed
							self.logger.log(50, 'wsExtension: Could not process response because it is not on the stack: ${message}');
							return;
						}

					} else {
						self.sendError("Response is not valid without stamp, data and ackCount properties!");
					}



					// OLD:
					/*
					if (!message.hasOwnProperty('requestStamp') || !message.hasOwnProperty('failureCode')){
						self.sendError("response is not valid without properties 'requestStamp' and 'failureCode'!");
					} else {
						if (message.requestStamp in self.stackRequest){
							if (message.failureCode){ // failurecode is the statusCode; 0=no failure and the success-callback is called
								// call the failure callback
								self.stackRequest[message.requestStamp].cbFailure(message.data, message.failureCode);
							}else{
								// call success callback
								self.stackRequest[message.requestStamp].cbSuccess(message.data);
							}
							// stop the interval and delete the request from the stack
							clearInterval(self.stackRequest[message.requestStamp].opt.interval);
							delete self.stackRequest[message.requestStamp];
						} else {
							this.logger.log(3, 'Stamp was not on stack. This happens when 1) (unlikely) somebody tries to hack you or 2) (likely) the server was very busy and could not send you an answer within your default waiting time so you sent the requst again and the server finally also processed every request (n-1 or even n times (when none of the replys came within the time between the first and the last request) for nothing...) or 3) (little likely) two responses were sent for the same request and thus the request was already removed from the stack. It is not allowed to have more than one response (currently) and thus the now received (second or later) response is unhandled/deleted.')
						}
						
					}
					*/

				},

				// response ack sent to system B (that processed the request and sent the response)
				responseAck: ()=>{

					// copied from requestAck
					// TODO: change differences: different concerning the status and success callbacks 
					
					// the ack received should look like this
					/*let ack = {
						type: 'responseAck',
						stamp: message.stamp,
						ackCount : message.ackCount +1 
					};*/

					if (!('stamp' in message && 'ackCount' in message)){
						// the ack cannot be processed
						self.logger.log(50, `wsExtension: Could not process responseAck because not all necessary properties were set: ${message}`);
						return;
					}

					// find the request on the stack here
					let stackObj;
					if (stackObj = self.stackIncomingRequest[message.stamp]){

						// check if it is an old, already processed ack:
						if (stackObj.ackCount>= message.ackCount){
							// do not process it, just do nothing
							this.logger.log(50, 'wsExtension: Recieved requestAck with ackCount < than the currently processed ack. The requestAck is ignored.');
							return;
						} 

						stackObj.ackCount = message.ackCount;

						// calculate the current status:
						if (stackObj.opt.executeAckCount < stackObj.ackCount){
							// we know that execution was started
							stackObj.status = 13;

							// TODO: should we stop here the timeout?

						} else if (stackObj.opt.executeAckCount == 1 + stackObj.ackCount){
							// after the ack sent now, execution will be started
							stackObj.status = 12;
						}

						// call the statusCB:
						stackObj.cbStatus(stackObj.status, stackObj.ackCount);

						// if there was an interval of sending ack's started, stop it now
						if (stackObj.opt.interval) {
							// stop the interval
							clearInterval(stackObj.opt.interval);
							delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running
						}

						// if needed send new ack; with interval, if needed.
						// first of all, if required, acknowledge having received the request, so that the request is not sent any further time
						if (message.ackCount<stackObj.opt.ackTotal) {
							
							// send the ack:
							let ack = {
								type: 'response',
								stamp: message.stamp,
								ackCount: message.ackCount +1
							}
							let mess = JSON.stringify(ack);
							self.sendingFunc(mess); // send it!
							stackObj.opt.lastSentAck = mess;

							// start interval, if needed:
							// if this (just sent) ack will also be ack'ed and retry is wanted: start interval for resending, if no ack arrived within the interval time 
							if (stackObj.opt.retryNumber > 0 && message.ackCount < stackObj.opt.ackTotal-1) {

								// initialize retryAttempts
								stackObj.opt.retryAttempts = 0;

								// TODO: continue here; start adding the callbacks 
								// TODO: make sure that in all funcitons (especially also responce), that it is recognised when the last message has arrived and that the stackObj is deleted then!

								stackobj.opt.interval = setInterval(()=>{
									this.logger.log(50, `wsExtension: The ack number ${message.ackCount+1} for the incoming responseAck ${stackObj.stamp} was not acknowledged within ${stackObj.opt.retryAttempts+1} attempts in the interval of ${stackObj.opt.retryInterval}ms.`);

									if (stackObj.opt.retryAttempts==stackObj.opt.retryNumber){
										// no further retry attempt

										clearInterval(stackObj.opt.interval); // stop the interval
										delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running

										// callbacks:
										// if the data was already executed, call the status callback, otherwise the failure callback
										if (stackObj.ackCount>=stackObj.opt.executeAckCount){
											//stackObj.cbStatus(`The ack ${stackObj.ackCount+1} could not be sent, but the response has already been processed.`, 1) //message, code
										//} else {
											stackObj.cbFailure(`The ack ${stackObj.ackCount+1} could not be sent and the response was (probably) not yet processed.`, 5) // TODO: here we could differentiate between: 'we know that the data was not processed yet' and 'the data might have ben processed' Add the failureCode to the list on top
										}
										
										// if the request is already executed, do nothing; if it is not yet executed, delete the request from the stack
										if (message.ackCount<message.executeAckCount) {
											delete self.stackRequest[message.stamp];
										}
									
										
									} else { // some more attempts to do --> send the request again
										if (self.closing){
											
											self.logger.log(50, `wsExtension: Connection lost. Ack number ${message.ackCount+1} for the incoming responseAck ${stackObj.stamp} was not acknowledged before the conection was closed.`);
											clearInterval(stackObj.opt.interval); // stop the interval 
											delete stackObj.opt.interval; // delete it, as we use the presense of the interval to know whether an interval is running

											// TODO: add Callbacks
											// call failureCB

											// if the request is already executed, do nothing; if it is not yet executed, delete the request from the stack
											if (message.ackCount<message.executeAckCount) {
												delete self.stackRequest[message.stamp];
											}
											
										} else {
											stackObj.opt.retryAttempts += 1;
											self.sendingFunc(stackObj.opt.lastSentAck);
										}
									}
								}, stackObj.opt.retryInterval);
							}


						}

						// if no more ack is expected, stop the timeout and delete the response from stack
						if (message.ackCount+1 >= stackObj.opt.ackTotal) {
							
							clearTimeout(stackObj.opt.timeout);

							// delete from the stack
							delete this.stackIncomingRequest[stackObj.stamp];
						}

					} else {
						// the ack cannot be processed
						self.logger.log(50, `wsExtension: Could not process responseAck because it is not on the stack: ${message}`);
						return;
					}

				},

				error: ()=> {
					this.logger.log(7, 'A client returned an error for a ws-package: ' + message.data.toString());
				}
			}
	
			if (typeof(messagetypes[message.type]) == 'function'){
				messagetypes[message.type]()
			} else {
				this.logger.log(7, message.type + ' is not a supported type of WebSocket data.');
			}
	
		}
	
	}