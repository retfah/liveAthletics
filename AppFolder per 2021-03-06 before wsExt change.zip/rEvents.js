
// the room for events

import roomServer from './roomServer.js';


/**
 * the room for event management (adding, deletign, updating,  ...)
 * The data stores a list of objects with the meeting data: data =[{event1}, {event2}]
 */
class rEvents extends roomServer{

    /** Constructor for the meetings-room
     * @method constructor
     * @param {string} meetingShortname
     * @param {sequelize} sequelizeMeeting sequelize The sequelize connection to the meetingDB
     * @param {sequelizeModels} modelsMeeting sequelize-models The sequelize models of the Meeting-DB
     * @param {mongoDb} mongoDb The mongoDb instance to be used.
     * @param {eventHandler} eventHandler The eventhandler instance
     * @param {logger} logger A logger instance
     * //@param {socketProcessor2} wsProcessor UNUSED The websocket processor instance; needed obviously for the  
     */
    constructor(meetingShortname, sequelizeMeeting, modelsMeeting, mongoDb, eventHandler, logger){

        // NOTE: when debugging, the variable 'this' is undefined when the debugger passes here on construction. Don't know why, but it works anyway.

        // call the parents constructor FIRST (as it initializes some variables to {}, that are extended here)
        // (eventHandler, mongoDb, logger, name, storeReadingClientInfos=false, maxWritingTicktes=-1, conflictChecking=false)
        super(eventHandler, mongoDb, logger, meetingShortname + '@events', true, -1, false);

        // initialize/define the default structure of the data (either an array [] or an object {})
        // we need to define this since roomDatasets will required the respective type, before the actual data is loaded
        this.data = []; 

        // the reference to the sequelizeAdmin connection
        this.seq = sequelizeMeeting;
        this.models = modelsMeeting;

        this.ready = false; // as we have async stuff here, we need to know whether we are ready to do something or not (e.g. the sequelize data is loaded.)

        // get all events
        this.models.events.findAll().then(events=>{
            this.data = events;
            this.ready = true;
        })

        // add the functions to the respective object of the parent
        // the name of the funcitons must be unique over BOTH objects!
        // VERY IMPORTANT: the variables MUST (!!!!!) be bound to this when assigned to the object. Otherwise they will be bound to the object, which means they only see the other functions in functionsWrite or functionsReadOnly respectively!
        
        this.functionsWrite.addEvent = this.addEvent.bind(this);
        //this.functionsReadOnly.TODO = this.TODO.bind(this);
        //this.functionsWrite.TODO2 = this.TODO2.bind(this);

        // define, compile and store the schemas:
        let schemaAddEvent = {
            type: "object",
            properties: {
                //xEvent: {type: "integer"},
                xDiscipline: {type: "integer"},
                xCategory: {type: "integer"},
                xEventGroup: {type: "integer"},
                entryFee: {type: "integer"}, 
                bailFee: {type: "integer"}, // not used so far!
                eventOnlineId: {type: "integer"},
                info: {type: "string", maxLength: 50}
            },
            required: ["xDiscipline", "xCategory", "entryFee", "info"] // xEventGroup should be present, but as it might be undefined, it is treated as not present!
        };
        let schemaUpdateEvent = {
            type: "object",
            properties: {
                xEvent: {type: "integer"},
                xDiscipline: {type: "integer"},
                xCategory: {type: "integer"},
                xEventGroup: {type: "integer"},
                entryFee: {type: "integer"}, 
                bailFee: {type: "integer"}, // not used so far!
                eventOnlineId: {type: "integer"},
                info: {type: "string", maxLength: 50}
            },
            required: ["xEvent", "xDiscipline", "xCategory", "xEventGroup", "entryFee", "info"]
        };
        let schemaDeleteEvent = {
            type: "integer"
        }
        this.validateAddEvent = this.ajv.compile(schemaAddEvent);
        this.validateUpdateEvent = this.ajv.compile(schemaUpdateEvent);
        this.validateDeleteEvent = this.ajv.compile(schemaDeleteEvent);

 
    }

    /**
     * add an event
     * @param {object} data This data shall already be in the format as can be used by Sequelize to insert the data. It will be checked with the schema first.
     */
    async addEvent(data){

        // validate the data based on the schema
        //let valid = this.ajv.validate(schema, data); 
        let valid = this.validateAddEvent(data);
        if (valid) {

            // translate the boolean values; it would work in the DB (translated automatically), but in the locally stored data and returned value in 'meeting' from sequelize, it would still be the untranslated data, i.e. with true/false instead of 1/0. 
            // Method 1: manually translate the booleans with the translateBooleans-function in roomServer --> not very efficient if executed on the whole data and every funciton like addMeeting, updateMeeting, ... would have to actively call this function in it
            // Method 2: implement setter on sequelize level. Better solution, as only implemented once for all possible functions.
            var dataTranslated = data; //this.translateBooleans(data);

            var event = await this.models.events.create(data).catch((err)=>{throw {message: `Sequelize-problem: Event could not be created: ${err}`, code:22}})

            this.data.push(event); 

            // the data to be sent back to the client requesting the add is teh full data
            let sendData = event.dataValues;

            // answer the calling client. it needs the same data as if it was an update, since we actually do an update for the id
            //responseFunc(sendData); --> done on resolve

            // object storing all data needed to DO the change
            let doObj = {
                funcName: 'addEvent',
                data: event.dataValues // should have the same properties as data, but with added xEvent
                // the UUID will be added on resolve
            }

            // object storing all data needed to UNDO the change
            // Not needed yet / TODO...
            let undoObj = {
                funcName: 'TODO', // deleteMeeting
                data: {}
                // the ID will be added on resolve
            };
            
            // do the rest (put on stack and report to other clients etc)
            let ret = {
                isAchange: true, 
                doObj: doObj, 
                undoObj: undoObj,
                response: sendData,
                preventBroadcastToCaller: true
            };
            return ret;
            
        } else {
            throw {message: this.ajv.errorsText(this.validateAddEvent.errors), code:23};
        }
    }


    async deleteEvent(data){

        // data must be an integer (the xMeeting id)
        let valid = this.validateDeleteEvent(data);

        if (valid){

            // get the entry from the data (respectively its index first):
            let [ind, event] = this.findObjInArrayByProp(this.data, 'xEvent', data)

            // delete the entry in the meetings table
            await this.models.events.destroy({where:{xEvent: data}}).catch(()=>{
                throw {message: "Event could not be deleted!", code:21}
            });

            // NOTE: also arrives here when the event actually did not exist (anymore!); However, should always exist!

            // delete the entry locally from the data:
            [ind, ] = this.findObjInArrayByProp(this.data, 'xEvent', data) // must be reqpeated, since the index could have changed due to the async call.
            if (ind>=0){
                this.data.splice(ind,1);
            }

            // object storing all data needed to DO the change
            let doObj = {
                funcName: 'deleteEvent',
                data: data
            }

            // object storing all data needed to UNDO the change
            // Not needed yet / TODO...
            let undoObj = {
                funcName: 'TODO', // addEvent
                data: {}
                // the ID will be added on resolve
            };
            
            // do the rest (put on stack and report to other clients etc)
            let ret = {
                isAchange: true, 
                doObj: doObj, 
                undoObj: undoObj,
                response: data,
                preventBroadcastToCaller: true
            };
            return ret;
            
        }else {
            throw {message: this.ajv.errorsText(this.validateDeleteEvent.errors), code:23};
        }
    }

    async updateMeeting(data){

        // check if the client has the rights to do a change!
        // TODO
        
        // validate the data based on the schema
        let valid = this.validateUpdateMeeting(data);
        if (valid) {

            return this.models.meetings.findByPk(data.xMeeting).then((meeting)=>{

                // store the old data for the undo-object
                let meetingOld = meeting.dataValues;

                // get the index of the meeting in the list of meetings
                let [i,o] = this.findObjInArrayByProp(this.data, 'xMeeting', data.xMeeting);
                if (i<0){
                    throw {code:24, message:"The meeting does not exist anymore on the server (should actually never happen)."};
                }

                // currently the function to change the shortname is untested; do not use it
                if (data.shortname!=this.data[i].shortname){
                    throw {code:28, message: "The shortname is not allowed to change, since the function is nto tested yet!"};
                }

                // update it
                return meeting.update(data).then(async(meetingChanged)=>{
                    // the data should be updated in th DB by now.

                    // undo the changes on error
                    var undo = async()=>{
                        // untested: 
                        return meetingChanged.update(meetingOld);
                    } 

                    // NOTE: the shortname currently (2021-01) is not changable after it was set!
                    // if the shortname changes, we need to rename the DB
                    if (meetingOld.shortname != meetingChanged.shortname){

                        // conneciton to the old DB
                        var DBconnOld;

                        // name of DBs
                        let nameOld = conf.database.dbMeetingPrefix + meetingOld.shortname;
                        let nameNew = conf.database.dbMeetingPrefix + meetingChanged.shortname;

                        // stop the meeting, if it was started
                        if (this.data[i].running){ // we need to read the property from the data-object since the meeting-variable is fromt he DB, where running does not exist! 
                            // store the old DB connection
                            DBconnOld = this.activeMeetings[meetingOld.shortname].seq;
                            await this.meetingShutdownOne(meetingOld.shortname);
                        } else {
                            // open a DB connection to the old meetingDB
                            DBconnOld = new Sequelize(nameOld, conf.database.username, conf.database.password, {
                                dialect: 'mariadb', // mysql, mariadb
                                dialectOptions: {
                                    multipleStatements: true, // attention: we need this option for creating meetings; however, it is dangerous as it allows SQL-injections!
                                    timezone: 'local', // sequelize would define an other default otherwise!
                                },
                                host: conf.database.host,
                                port: conf.database.port,
                                //operatorsAliases: false, no option anymore
                                logging: false,
                                // application wide model options: 
                                define: {
                                    timestamps: false // we generally do not want timestamps in the database in every record, or do we?
                                }
                            })
                        }
                        

                        // a DB cannot simply be renamed, unfortunately...
                        // so we need to create first the new DB
                        await mysqlConn.query(`create database if not exists ${nameNew}`).catch(async (error)=>{await undo(); throw {message: `Database could not be created: ${error}`, code:24};})

                        // get a connection to the new DB
                        try {
                            var DBconnNew = new Sequelize(nameNew, conf.database.username, conf.database.password, {
                                dialect: 'mariadb', // mysql, mariadb
                                dialectOptions: {
                                    multipleStatements: true, // attention: we need this option for creating meetings; however, it is dangerous as it allows SQL-injections!
                                    timezone: 'local', // sequelize would define an other default otherwise!
                                },
                                host: conf.database.host,
                                port: conf.database.port,
                                //operatorsAliases: false, no option anymore
                                logging: false,
                                // application wide model options: 
                                define: {
                                    timestamps: false // we generally do not want timestamps in the database in every record, or do we?
                                }
                            })
                        } catch (error) {
                            await undo();
                            throw {message: `Error on creating new DB connection: ${error}`, code:25}
                        }

                        // then we move all tables to the new DB
                        // ATTENTION: this might work differently with different DBs. For mariaDB showAllSchemas returns the names of the tables
                        await DBconnOld.showAllSchemas().then(schemas =>{
                            // schemas = ["table1", "table2", ...]
                            schemas.forEach(async(tableName, index)=>{
                                await DBconnOld.query(`rename table ${meeting.shortname}.${tableName} to ${meetingChanged.shortname}.${tableName}`)
                            })

                        }).catch(err=>{
                            undo();
                            throw({message: 'Something went wrong when transferring tables form the old to the new DB: '+err, code: 26});
                        })

                        // finally delete the old DB
                        await mysqlConn.query(`drop database if exists ${nameOld}`).catch((err)=>{logger.log(`Database '${nameOld}' could not be deleted: ${err}`);}).catch(err=>{
                            this.logger.log(20, `update shortname: old database could not be deleted: ${err}. All other things were successful.`)
                        }) 

                        // change the entry in the associated list
                        delete this.meetingsAssoc[meetingOld.shortname]
                        this.meetingsAssoc[meetingChanged.shortname] = meetingChanged;

                        
                        // add the additional proeprty "running"
                        meetingChanged.running = false; 

                        // if the meeting shall be active, start the meeting
                        if (meetingChanged.active){
                            this.meetingStartupOne(meetingChanged.shortname, DBconnNew)
                        }
                    } else {

                        // check whether the active state should have changed and add the running property accordingly
                        if (meetingChanged.active){
                            if (this.data[i].running){
                                // was already runnign before, so just set the running property
                                meetingChanged.running = true;
                            } else {
                                // we need to start it up
                                meetingChanged.running = false;
                                this.meetingStartupOne(meetingChanged.shortname, DBconnNew); // will change 'running' to true
                            }

                        } else {
                            if (this.data[i].running){
                                // was runnign before, should be shut down now
                                meetingChanged.running = true; 
                                this.meetingShutdownOne(meetingChanged.shortname)
                            } else {
                                // it is and should be not running
                                meetingChanged.running = false;
                            }
                        }

                    }

                    // set the local data
                    this.data[i] = meetingChanged;

                    let ret = {
                        isAchange: true, 
                        doObj: {funcName: 'updateMeeting', data: data}, 
                        undoObj: {funcName: 'updateMeeting', data: meetingOld, ID: this.ID},
                        response: true,
                        preventBroadcastToCaller: true
                    };
                    
                    // the rest is done in the parent
                    return ret;

                }).catch((err)=>{
                    throw {code: 22, message: "Could not update the meeting with the respective Id. Error: " + err};
                });
            }).catch((err)=>{
                throw {code:21, message: "Could not load the meeting with the respective Id. Error: " + err}
            });


        } else {
            throw {code: 23, message: this.ajv.errorsText(this.validateUpdateMeeting.errors)}
        }
    }

    // activates the meeting, i.e. sets meeting.active=true, such that also after restart of the server it will be started. This will already result in sending the response. Then it tries to start the meeting and will report this to all clients after success.
    async activateMeeting(xMeeting){

        if (!this.validateActivateMeeting(xMeeting)){
            throw {code: 23, message: this.ajv.errorsText(this.validateActivateMeeting.errors)};
        }

        // try to get the shortname for the meeting
        let [i,meeting] = this.findObjInArrayByProp(this.data, 'xMeeting', xMeeting); // index and object
        if(i==-1){
            throw {code: 24, message:'Could not find meeting for the given xMeeting.'};
        }

        // set the active state, such that it will also be automatically started on server restart
        meeting.active = true;
        await meeting.save(); // save to DB

        // (async) start the meeting (if it is already started, an error 53 will be raised)
        this.meetingStartupOne(meeting.shortname).catch(()=>{}); // make sure that errors are not unhandled.

        let ret = {
            isAchange: true, 
            doObj: {funcName: 'activateMeeting', data: xMeeting}, 
            undoObj: {funcName: 'deactivateMeeting', data: xMeeting, ID: this.ID},
            response: xMeeting,
            preventBroadcastToCaller: true
        };

        return ret;
        
    }

    async deactivateMeeting(xMeeting){
        if(!this.validateDeactivateMeeting(xMeeting)){
            throw {code: 23, message: this.ajv.errorsText(this.validateDeactivateMeeting.errors)};
        }

        // try to get the shortname for the meeting
        let [i,meeting] = this.findObjInArrayByProp(this.data, 'xMeeting', xMeeting); // index and object
        if(i==-1){
            throw {code: 24, message:'Could not find meeting for the given xMeeting.'};
        }

        // set the active state
        meeting.active = false;
        await meeting.save(); // save to DB

        // async shutdown of the meeting:
        this.meetingShutdownOne(meeting.shortname).catch(()=>{this.logger.log(10, `The meeting ${meeting.shortname} could not be shut down. No message could be sent to the requesting client, since the request was already resolved.`)}); // make sure that errors are not unhandled.

        let ret = {
            isAchange: true,
            doObj: {funcName: 'deactivateMeeting', data: xMeeting}, 
            undoObj: {funcName: 'activateMeeting', data: xMeeting, ID: this.ID}, 
            response: xMeeting,
            preventBroadcastToCaller: true
        }

        return ret;

    }

    async backupMeeting(data){
        // validate
        let valid = this.validateBackupMeeting(data);
        if (valid){
            let xMeeting = data;

            // get the array index
            let [i,o] = this.findObjInArrayByProp(this.data, 'xMeeting', xMeeting);

            let sql = await mysqldump({
                connection:{
                    host: conf.database.host,
                    port: conf.database.port,
                    user: conf.database.user,
                    password: conf.database.password,
                    database: 'foreign-athletes' // TODO: change this to the correct database after testing: conf.database.dbMeetingPrefix + this.data[i].shortname
                    // attention: if we use the shortname of the meeting for the DB-name (which makes debugging easy), then we have to change the db name when the shortname is changed, which also requires a restart of all rooms, i.e. changing the shortname only works when the meeting is not active.
                }
            })

            // store the sql together with some background info (e.g. version of DB) in a compressed file
            // the raw-file is just text in a similar structure as a http header, i.e. one named param per line, the content starts after an empty line
            // the raw-file is then gzipped and base64 encoded for sending.
            let backupRaw = '';

            // parameters:
            backupRaw += "version="+conf.database.version+"\r\n";
            backupRaw += "timestamp="+Date.now()+"\r\n";
            // eventually we need more parameters, e.g. to say what is stored, for example with/out base data

            // data to follow
            backupRaw += "\r\n"; // empty row
            backupRaw += sql;

            let buffer = Buffer.from(backupRaw);

            // currently zlib uses callbacks instead of promises, thus we need to promisify the call... TODO: change to proper promises syntax as soon as it is supported
            return new Promise((resolve, reject)=>{
                zlib.gzip(buffer, (err, gzBuffer)=>{
                    if (err){
                        reject({code: 24, message: 'gzip-error: '+err})
                    }
                    let backup =  gzBuffer.toString('base64');
                    
                    resolve(backup);
                })
            })


            /**
             * NOTE: it is actually not intended that the browser creates its own files and stores it, but which is what we actually do here when we transfer the file via Websockets. The following way we can store the data in the browser through javascript (copied from)
             * function download(filename, text) {
                var element = document.createElement('a');
                element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
                // data:application/gzip;base64,<the data> for gzip stuff
                element.setAttribute('download', filename);

                element.style.display = 'none';
                document.body.appendChild(element);

                element.click();

                document.body.removeChild(element);
                }

                // Start file download.
                download("hello.txt","This is the content of my file :)");

             */

        }else {
            throw {code: 23, message: this.ajv.errorsText(this.validateBackupMeeting.errors)}
        }

    }

    async restoreMeeting(data){
        let valid = this.validateRestoreMeeting(data);
        if (valid){

            let xMeeting = data.xMeeting;
            let backup = data.backup;

            // get the array index
            let [i,o] = this.findObjInArrayByProp(this.data, 'xMeeting', xMeeting);

            // check first that the meeting is not running and is not getting started!
            if (this.data[i].running || this.data[i].active){
                throw {code: 24, message: 'The meeting is running or is getting started up. No restoring possible.'}
            }

            // parse the backup:

            
            // reset in EVERY room the stack and stackId's; all clients and other servers will have to reload everything!
            // create a new ID for every room


        }else {
            throw {code: 23, message: this.ajv.errorsText(this.validateRestoreMeeting.errors)}
        }
    }


    /**
     * Load all meetings from new (=load or reload)
     * @method loadNew 
     */
    async loadNew(){ // if we wanted to use await, the function must be declared async --> async loadNew()
        //await this.models.meetings.findAll().then((meetings)=>{
        await this.models.meetings.findAll().then((meetings)=>{

            // store the data to the parant's class property 'data'
            this.data = meetings;

            // add the property running (the property "active" is used and denotes: shall be activated. Running means, all the rooms of the meeting are running on the server)
            this.data.forEach(el=>{el.running=false});

            // create an object with properties = shortname and value=meeting
            this.meetingsAssoc = fetchAssoc(meetings, 'shortname'); 

            //this.ready = true;
            this.logger.log(99, 'Meetings initially loaded!');
        }).catch((err)=>{this.logger.log(1, `Could not load the meetings: ${err}`)})
    }

    // TODO: rewrite this funciton (if needed), in order not to use a mysql call for this but rather search through the objects (if this is faster..?)
    /**
     * Get the shortname of the meeting with the given xMeeting
     * @param {înteger} id xMeeting
     */
/*     async getShortnameById(id){
        this.models.meetings.findByPk(id).then((meeting)=>{
            return meeting.shortname;
        }).catch((error)=>{
            throw {message: `Could not find shortname for xMeeting=${id}: ${error}`, code:51};
        })
    } */

    // --------------------------------------------------------------
    // maybe the following functions should be outside this function

    /**
     * start up all meetings. (generate the necessary rooms, register the path, ...)
     * @method meetingStartupAll
     */
    async meetingStartupAll(){
        for (let i=0;i<this.data.length;i++){
            let m = this.data[i];
            if (m.active){
                await this.meetingStartupOne(m.shortname);
            }
        }
    }

    /**
     * start up one meeting (generate the necessary rooms, register the path, ...)
     * @method meetingStartupOne
     * @param {string} shortname The shortname of the meeting
     */
    async meetingStartupOne(shortname, seq=undefined){
        // get the respective meeting
        let meeting = this.meetingsAssoc[shortname];

        if (shortname in this.activeMeetings){
            throw {message: `Cannot start meeting, as it already exists/is started`, code:53}
        } else {
            this.activeMeetings[shortname] = {};
        }

        // start the sequelize connection
        // if seq is given, this was done already (e.g. when the meeting was created)
        var name = conf.database.dbMeetingPrefix + shortname;

        if (!seq){
            seq = new Sequelize(name, conf.database.username, conf.database.password, {
                dialect: 'mariadb', // mysql, mariadb
                dialectOptions: {
                    multipleStatements: true, // attention: we need this option for creating meetings; however, it is dangerous as it allows SQL-injections!
                    timezone: 'local',
                },
                host: conf.database.host,
                port: conf.database.port,
                //operatorsAliases: false, no option anymore
                logging: false,
                // application wide model options: 
                define: {
                    timestamps: false // we generally do not want timestamps in the database in every record, or do we?
                }
            })
            // check if everything worked well:
            await seq.authenticate().catch((err)=>{throw {message: `Connection to meeting DB (through sequelize) could not be established: ${err}`, code: 52}})
        }

        // store the sequelize connection
        this.activeMeetings[shortname].seq = seq;

        // define that the meeting is running. 
        meeting.running = true;

        // when the room was already ready, then clients might already have received data, where meeting.running=false was set. Thus now set this to true and report it to all clients
        if (this.ready){

            let doObj = {funcName: 'runMeeting', data:meeting.xMeeting}
            let undoObj = {}; // nothing to undo; when the undo-function of activateMeeting (=deactivateMeeting) is called, also running will be changed. 
            
            this.processChange(doObj, undoObj)   
        }

        // TODO:
        // 0) TODO: what must be done for modules? Note: if modules have dependecies, the order must be correct!
        // 1) load all the associated rooms for this meeting
        // 2) connect all push-clients (slaves) to these rooms

        // true=success
        return true;

    }

    /**
     * shut down all meetings. stop the rooms, unregister the path, ...)
     * @method meetingShutdownAll
     */
    meetingShutdownAll(){
        return;
    }

    /**
     * shut down one meeting (stop the rooms, unregister the path, ...)
     * @method meetingShutdownOne
     * @param {string} shortname The shortname of the meeting
     */
    async meetingShutdownOne(shortname){

        // get the respective meeting
        let meeting = this.meetingsAssoc[shortname]; // data

        if (!(shortname in this.activeMeetings)){
            throw {message: `Cannot stop meeting, as it is not started`, code:53}
        } 
        let activeMeeting = this.activeMeetings[shortname]; // contains the sequelize connection, the rooms, etc
    
        // stop all rooms etc
        // TODO...

        // stop the sequelize-DB-connection
        await activeMeeting.seq.close() 

        // remove the meeting from the activeMeetings-array
        delete this.activeMeetings[shortname];

        // set the meeting as not running:
        meeting.running = false;

        // report the clients that the meeting was stopped. 
        if (this.ready){
            let doObj = {funcName: 'stopMeeting', data:meeting.xMeeting}
            let undoObj = {}; // nothing to undo; when the undo-function of deactivateMeeting (=activateMeeting) is called, also stopping will be changed. 
            this.processChange(doObj, undoObj)   
        }

        return true;
    }
}

// TODO: move the following function into a file with general methods like this
/**
 * @method fetchAssoc Returns an object with properties given by the 'property' in each object of the array and the object itself as the value. The property must be unique. Otherwise the method returns false. 
 * @property {object array} a  The array with the objects, where the property 'property' must exist in every object and must be unique.
 * @property {string} property The property to be used for the associations
 */

function fetchAssoc(a, property){
    try {
        let oAssoc = {};
        for (let i=0;i<a.length;i++){
            let el = a[i];
            if (property in el && !(el[property] in oAssoc)){
                oAssoc[el[property]] = el;
            }else{
                return false;
            }
        }
        return oAssoc;
    }catch(ex){
        // all errors such as "a is not an array", "property does not exist" will end up here 
        return false;
    }
} 


// the way of exporting for node (currently 03.2019)
//module.exports = rEvents;
export default rEvents;