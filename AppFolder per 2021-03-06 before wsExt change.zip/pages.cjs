// here we define the setup of all pages
// the injection is done via javascript on the client and with ejs on the server
// - injectionsIDs should be unique over all pages to avoid problems, as every subsequent inject will simply override the previous ones
// the injectID 'title' and 'pages' must not be used, as they are used to set the browser title and pages and thus must be passed form the last child to the root without beeing changed/overwritten!

// TODO: could be extended with:
// - every page should store a list of its injectionsIDs --> would allow to delete renderData after it was injected and thus injectionIDs would not need to be unique over all pages, but only on this page

module.exports = {

    /*
    reference (up to date: 12.5.2018):
    name:       string, mandatory   it's own name; "self-reference" in order that in the page-object itself the name is still known
    file:       string, optional    the root file to be loaded; must contain a proper html site starting with <html>; either file or parent must be given!
    parent:     string, optinoal    the name of the parent, where the data defined in 'injections' is injected in the respective injectdionIDs; either file or parent must be given!
    injections: object, mandatory except for root; Object with keys=injectionIDs of parent (or grand-parent etc) and value=Object with either file and optional data (injectID1) or text (injectID2); example: {injectID1: {file: Filename.ejs , data: {injectID3: 'hello', injectID4: 'world'}}, injectID2: {text: "this text is directly inserted without any processing"}}
    injectionsSelf: object, optional only when not root; injections to be done in its own file(s) defined in injection, if this page is requested (not a subpage). 
    title:      string, mandatory   the title of the page; always the lowest (in the hierarchy) available title is shown; is going to be translated, so set in the default language
    preload:    [string], optional  array of pages that shall be preloaded for faster page change if this page is any of root up to childest page
    preloadSelf: [string], optional  array of pages that shall be preloaded for faster page change only if this page is the 'childest' page
    onLoad:     string, optional    function name of the function to be called on loading the page
    onUnload:   string, optional    function name of the function to be called on UNloading the page --> important for termining room-subscriptions; MUST return true on success or false on failure (then the next page will be loaded via http and the unloading is not done, respectively will be done automatically, as the Websocket-connction is lost.)

    ATTENTION: pages is not allowed to have functions! Only objects that can be stringified!
    */
    root: {
        name: 'root',
        /* is the root;
        especially brings along some javascript logic:
        - for the partial site updating.
        - changes the link classes to active when the respective child-site is currently shown
        */
        file: "root.ejs", // each page can have file or parent!
        injectionsSelf: {child1:{text:"WELCOME"}}, // TODO: replace this with a real welcome page
        //parent: "NONE",
        title: "liveAthletics", // default title, when all other elements have no title
        preload : ['configuration', 'competition'] ,
        preloadSelf: []
    },

    configuration: {
        name: 'configuration',
        //file: "configuration.ejs", // each page can either have a parent or a file; if there is a parent, the files to be injected are
        injections: {child1: {file:'configuration.ejs'}}, // injections in the parent; data should not be defined (as can be in injectionsSelf, except if the injects of the parent shall be overwritten!)
        injectionsSelf: {child2: {file:'configurationSelf.ejs', data:{inj:'This is injected! And cannot be translated this way!'}}}, // only injected when itself is the last child; must fill all the ids of the page, simplest would be childX:{text:''}; in the inner object file and text is available; with file, additional data-injections can be defined here: currently only data is supported and no further files with their data and so on --> could be done with recursion  
        preload : ['athletes', 'competition', 'definition'], // TODO: change this to the real values, this is only for testing
        parent: 'root',
        title: 'Configuration' 
    },

    definition:{
        name: 'definition',
        //injections: {child2: {text: "This is the definitions page."}},
        injections: {child2: {file: "eventMgr.ejs"}},
        injectionsSelf: {},
        parent: 'configuration',
        title: 'Definition',
        onLoad: 'startup'
    },

    competition: {
        name: 'competition',
        injections: {child1: {text:'This is the competition inserted text!'}},
        preload: ['configuration'],
        parent: 'root',
        title: 'Competition'
    },

    athletes: {
        name: 'athletes',
        // provides the athletes overview and links to the related options, like add new, alter, printRecipt, ...
        injections: {child2: {file: 'athletes.ejs', data: {}}},
        //file: 'athletes.ejs',
        parent: 'configuration',
        //injectID: 'child1',
        preload: ['configuration', 'definition' ], // 'athleteRecipt', 'athleteAdd', 'athleteAlter'
        title: "Athletes"
        //, // addAthlete and alterAthlete might be represented in one single file with different data in/out
        // should expose at least 'athleteChanged' event --> find a way to do that
    } ,

    /* does not exist anymore, since it is its own page without the pageHandling stuff
    adminServer: {
        name: 'adminServer',
        // TODO: this is only temporary here, as it will go into a page outside the actual athletica!
        injections: {child1: {file: 'adminServer.ejs', data:{}}},
        parent: 'root',
        title: 'Server admin',
        onLoad: 'load', 
        onUnload: 'adminServerUnload' 
    }
    */

    /*,

    athleteAdd: {
        name: 'athleteAdd',
        injections: [{'child3': 'addAthletes.ejs'}],
        //file: 'addAthlete.ejs',
        parent: 'athletes',
        //injectID: 'child1',
        onLoad: 'functionOnload', // the function that has to be called after loading.
        onUnload: 'functionOnUnload' 
    }*/

    // all pages shall have a subscription for events (e.g. when an athlete is clicked, an action in the child page 'alterAthlete' must be done (load the newly selected athlete))
};