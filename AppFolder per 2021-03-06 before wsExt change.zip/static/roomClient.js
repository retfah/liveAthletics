//import { timingSafeEqual } from "crypto";

// the base class for rooms on the client:
// startup: connect to room on the server
// have a stack for every change made on the client
// always try to reduce the stack one by one, syncing with the server as fast as possible
// work as if the connection was not reliable, e.g. always require an acknowledgment 

// handling non-success from the server (e.g. on conflicting changes): have undo-functions for every entry on the stack and rollback all entries starting from the last entry on the stack (e.g. not the first one that was )

// as the roomManager cannot add getters/setters to the properties of instances of this class, we must inform it about changes it must show by raising the event 'roomInfoChange'!

class roomClient {

    /**
     * 
     * @param {roomClientVue} v The first vue that will be linked to that room. If v=undefined, then the room will still be opened, but without linked room.
     * @param {string} name The name of the room to connect to. 
     * @param {wsHandler} wsHandler The wshandler to use for sending data to the server
     * @param {eventHandler} eventHandler The used eventHandler instance, allowing different 'modules'/'rooms' to communicate through named signals 
     * @param {boolean} onlineOnly Only perform writing changes when online. This is a restriction some rooms will apply to make sure they are not getting outdated. it is complementary to other conflict avoiding measures on the servers like checking out tickets. 
     * @param {boolean} writing Set to true when this clients wants to write (even if we then cannot gather writingRights)
     * @param {function} success callback function called on connecting attempt
     * @param {function} failure callback function called on connecting attempt
     * @param {boolean} storeInfos Whather or not to store infos about the other clients locally. It will always be up to date, if true, otherwise it stays empty. Default=false
     * @param {roomManager} rM The roomManager
     * @param {string} datasetName The name of the dataset to get (''=room data=default)
     * @param {function} writingChangedCB callback function when the writing rights did change. TODO
     */
    constructor(v, name, wsHandler, eventHandler, onlineOnly, writing, success, failure, storeInfos=false, rM, datasetName='', writingChangedCB){

        // here the data-model is stored.
        this.data = {}
        this.dataPresent = false;

        // all views that use the data of this room shall be registered
        if (v){
            this.vues = [v];
        }else{
            this.vues = [];
        }

        // store the name of the room
        this.name = name;

        // we store whether writing is wanted or not. It is NOT related to whether we have a writing ticket or not!
        this.writingWanted = writing;

        // set the writign tickets ID, if there was already one.
        // false if this client has no writing rights (yet). If writing rights are requested (writing=true), this will store the writingTicketID (as the name already says) 
        this.writingTicketID = false;
        if ('localStorage' in window){
            let key = this.name + "writingTicketID";
            let val;
            if (val = window.localStorage.getItem[key]){
                this.writingTicketID = val;
            }
        } else{
            logger.log(7, 'Local Storage is not supported. Please use a modern browser.')
        }
        // save the CB function for wrting-ticket-ID changes. This allows the inheriting class to either 1) try reconecting without 


        // store the roomManager
        this.rM = rM;

        // give the client a name; used to identify the client in rooms; needed especially when a client does not return the writing ticket appropriately and an admin-client must delete the phantom writing ticket  
        this.clientName = rM.data.clientName; 

        
        // should the list of the other clients be stored?
        this.storeInfos = storeInfos;

        // which dataset should we request (by default '', which is the room data itself)
        this.datasetName = datasetName;

        //this.clients = {};
        this.infos = {} // the object that stores infos: numClients, numClientsWriting, maxWritingClients, clients
        
        // initialize the stack for the messages
        this.stack = [];

        // write only when online. This is a restrictive mode to avoid conflicting changes on the server, as this assures that each client that is trying to write is up to date first. When true, this also (kind of) disables the stack, as we do not store any change. Either it can be sent directly or the change is declined.
        // TODO: This variable can be used together with the online-status in Vue.js to enable/disable any control that will be not allowed to send when not online.
        this.onlineOnly = onlineOnly;

        // set the socketProcessor (ws-handler)
        this.wsHandler = wsHandler;
        
        // property storing the information whether a request is currently processed or not
        this.dataSent = false;

        // the (UU)ID of the last status synced with the server; this is needed in order to know if there are potentional conflicting changes and to be able to send differential changes to the client, if needed. 
        this.ID = 0; // to be initialized by the inheriting class!

        // all the special functions available in this room must be stored in the following object (IMPORTANT NOTE: this must be done by the child class!)
        // there is no async stuff and no error handling (thus not like on the server)
        // the function must take the data as the argument
        this.functions = {};

        // store whether the room is connected or not
        this.connected = false;

        // needed in tabId-reported-event
        this.connecting = false;

        if (wsHandler.connected && wsHandler.tabIdReported){
            // start connecting immediately
            this.connect(writing, success, failure);
        }

        // --> react on lost ws-connection --> change to connected=false
        this.eH = eventHandler;
        eH.eventSubscribe('tabIdSet', ()=>{
            if (!this.connected && !this.connecting){ //do not try to reconnect when we are connected (however, when tabIdset is correctly only reported once per running connection, this would not be necessary)
                this.connect(writing, success, failure)
                if (this.stack.length>0){
                    this.sync();
                }
            }
        });
        eH.eventSubscribe('wsClosed', ()=>{
            this.connected = false;

            // if the connection is lost while a request was hanging, the response will never arrive, as the "reopened" connection is not reopened, but is a new one and the server will not be able to send the reponse through the new connection. The last sent (or probably sent) element will stay on the stack and it wil be tried to resend it. When no other change-requst was processed yet, then the server will reply the response directly without reprocessing it and otherwise will return an error and the client will reload everything. 
            this.dataSent = false;

            // inform the roomManager 
            this.eH.raise('roomInfoChange');
        });
        
    }

    //{"type":"object", "properties":{"writing":{"type": boolean, "description": "optional, whether or not this connection also intends to write in this room"}, writingTicketID:{"type":"string", "description":"optional, the former writing-ticket-ID"} , "ID":{"type": "string", "description":"optional, the UUID of the current data-status present on the client"}, "name": {"type":"string", "description": "optional, a name of the client used to identify it. Used on the server only if writing is true"}}}

    /**
     * (Re-)Connect to the room
     * @param {boolean} writing Set to true when this clients wants to write 
     * @param {function} success callback function called after successful connecting attempt
     * @param {function} failure callback function called on connecting attempt, arguments: msg, code
     */
    connect(writing, success=()=>{}, failure=()=>{}){
        let opt = {writing:writing};
        if (this.writingTicketID){
            opt.writingTicketID = this.writingTicketID;
        }
        if (this.ID) { // ID=0 when not connected before which is evaluated to false
            opt.ID = this.ID;
        }
        
        // store the client name at request time
        let clientNameRequest = this.clientName;

        // prepare the options
        opt.name = clientNameRequest;
        opt.storeInfos = this.storeInfos;
        // dicontinued: the use of roomViews: 
        // opt.roomViews
        // opt.enterRoom
        opt.datasetName = this.datasetName;

        var numAttempts = 0;
        var maxAttemps = 10; // how many times it will be tested to (re)-connect to the server (if it formerly was not ready yet.) -1 for infinity

        this.connecting = true;

        var request = ()=>{

            numAttempts += 1;

            this.wsHandler.emitRequest('room', {
                roomName: this.name, // the name of the room
                arg: 'enter', // enter room
                opt: opt 
            }, (data)=>{
                
                let text = 'Sucessfully connected to room ' + this.name;
                
                this.connecting = false;

                // if the client's name has changed during the request to the server, send it the new name now (because setClientName would correctly not have sent it):
                if (this.clientName != clientNameRequest){
                    this.setClientName(this.clientName, true); // true=override 'no-change-check'
                }

                if (data.type=='full'){
                    // just set the local data to what we received
                    this.data = data.data;
                    this.ID = data.ID

                    if (data.writingTicketID){
                        this.setWritingTicketID(data.writingTicketID)
                        text += " with writingTicktID " + data.writingTicketID;
                    }else{
                        // when we had a wiritng ticket before the current (re-)connect, delete the old ticket
                        this.deleteWritingTicketID();
                    }
                    if (data.infos){
                        this.infos = data.infos;
                        // eventually we need to raise an event here that is listened by the room manager
                        this.eH.raise('roomInfoChange');
                    }

                    logger.log(99, text + '. Full data update.');

                    this.afterFullreload();
    
                    // call the success callback with no arguments; the success function will then make sure that the data is further processed
                    success(); 

                } else if (data.type=='incremental'){
                    // TODO: the data.data are the incremental changes to be run. this means the respective functions on the client must be run. If a function for a specific change is not available, request the full new data. Do NOT set the ID already!
    
                    // check if all required functions are available.
                    let funcsAvail = true;
                    // data.data is a sorted (!) array of objects with properties 'funcName' and 'data'
                    for (let i=0; i<data.data.length; i++){
                        if (!(data.data[i].funcName in this.functions)){
                            funcsAvail = false;
                            break;
                        }
                    }
    
                    if (funcsAvail){
                        // run all the incremental changes
                        for (let i=0;i<data.data.length; i++){
                            this.functions[data.data[i].funcName](data.data[i].data); // looks quite strange with this triple 'data', but it's correct
                        }
    
                        // finally:
                        this.ID = data.ID;
                        if (data.writingTicketID){
                            this.setWritingTicketID(data.writingTicketID);
                            text += " with writingTicktID " + data.writingTicketID;
                        }else{
                            // when we had a wiritng ticket before the current (re-)connect, delete the old ticket
                            this.deleteWritingTicketID();
                        }
                        if (data.infos){
                            this.infos = data.infos;
                            // eventually we need to raise an event here that is listened by the room manager
                            this.eH.raise('roomInfoChange');
                        }

                        logger.log(99, text + '. Incremental data update done.')

                        success();

                    } else {
                        logger.log(99, text + '. But sent incremental data could not be processed. Full data request hanging.');
                        this.getFullData(success, failure);
                    }
                }

                if (!(this.dataPresent)){
                    this.dataPresent = true;
                    
                    // raise dataArrived-events on all vues
                    this.vues.forEach(el=>el.dataArrived()) 
                }
                
                this.connected = true; 
    
            }, (msg, code)=>{
    
                // for certain codes, retry after a short delay
                // 4, 17: Server not ready yet (e.g. after a restart) (4: room does not exist yet; 17: room exists, but is not ready) --> try again after 1s
                // before 2020-01: 18: no writingTickets available --> delete current writing ticket (if present)
                if ([4, 17].indexOf(code)>=0){
                    // retry in 1s
                    logger.log(50, 'Server was not ready yet (codes 4 or 17). Retry in 1s'); 
                    if (numAttempts<maxAttemps || maxAttemps==-1){
                        setTimeout(request,1000); // TODO: test the new changes!
                    } else {
                        failure('Could not connect to server within ' + maxAttemps + ' attempts, as the server was not ready yet.', 23);
                        this.connecting = false;
                    }

                } /*OLD: else if (code==18){
                    logger.log(7, 'Could not get a writing ticket.')
                    this.deleteWritingTicketID();
                    // TODO: maybe let the inheriting class define a callback, that would be called now.
                    failure(msg, code);
                }*/ else {
                    logger.log(3, 'Connecting to room failed with the following code and message: ' + code + ": " + msg);
                    failure('Connecting to room failed with the following code and message: ' + code + ": " + msg, code)
                }
            });
        }



        // start the request:
        request();

        /*this.wsHandler.emitRequest('room', {
            roomName: this.name, // the name of the room
            arg: 'enter', // enter room
            opt: opt 
        }, (data)=>{
            if (data.type=='full'){
                // just set the local data to what we received
                this.data = data.data;
                this.ID = data.ID
                if (data.writingTicketID){
                    this.setWritingTicketID(data.writingTicketID)
                }

                // call the success callback with no arguments; the success function will then make sure that the data is further processed
                success(); 
            } else if (data.type=='incremental'){
                // TODO: the data.data are the incremental changes to be run. this means the respective functions on the client must be run. If a function for a specific change is not available, request the full new data. Do NOT set the ID already!

                // check if all required functions are available.
                let funcsAvail = true;
                // data.data is a sorted (!) array of objects with properties 'funcName' and 'data'
                for (let i=0; i<data.data.length; i++){
                    if (!(data.data[i].funcName in this.functions)){
                        funcsAvail = false;
                        break;
                    }
                }

                if (funcsAvail){
                    // run all the incremental changes
                    for (let i=0;i<data.data.length; i++){
                        this.functions[data.data[i].funcName](data.data[i].data); // looks quite strange with this triple 'data', but it's correct
                    }

                    // finally:
                    this.ID = data.ID;
                    if (data.writingTicketID){
                        this.setWritingTicketID(data.writingTicketID;)
                    }
                } else {
                    // request the full data!
                    this.wsHandler.emitRequest('room', {
                        roomName: this.name,
                        arg: 'fullData',
                        opt: {}
                    }, (data)=>{
                        this.ID = data.ID
                        this.data = data.data;
                    }, (code, msg)=>{
                        logger.log(3, "Could not get the full data for some strange reason. Code: " + code + " , message: " + msg)
                        
                        // call the failure callback
                        failure(code, msg);
                    });
                }
            }
            
            this.connected = true;

        }, (code, msg)=>{

            // for certain codes, retry after a short delay
            // 4, 17: Server not ready yet (e.g. after a restart) (4: room does not exist yet; 17: room exists, but is not ready) --> try again after 1s
            // 18: no writingTickets available --> delete current writing ticket (if present)
            if ([4, 17].indexOf(code)>=0){
                // retry in 1s
                logger.log(50, 'Server was not ready yet (codes 4 or 17). Retry in 1s'); 
                // TODO
            } else if (code==18){
                logger.log(7, 'Could not get a writing ticket.')
                this.deleteWritingTicketID();
                // TODO: maybe let the inheriting class define a callback, that would be called now.
            } else {
                logger.log(3, 'Connecting to room failed with the following code and message: ' + code + ": " + msg);
                failure(3, 'Connecting to room failed with the following code and message: ' + code + ": " + msg)
            }
        });*/
    }

    /**
     * Leave the room. This MUST be called on leaving the site in order to make sure that the writing ticket is 'given back'
     * TODO: there should be some function that closes the room/view (in room manager) when there is no connected vue instance (this.vues) anymore
     */
    leave(){

        // TODO: leave the room and give the writing ticket back (call to server) and delete the ticket 
        this.wsHandler.emitNote('room', {
            roomName: this.name, // the name of the room
            arg: 'leave', // enter room
            opt: {}
        });
        this.deleteWritingTicketID();
    }

    /**
     * Return the writingTicket we currently have, when the connection is ok
     * UNTESTED!
     */
    returnWritingTicket(){
        if (this.connected){
                
            // we do not want writingTicket anymore
            this.writingWanted = false;
            this.deleteWritingTicketID();
            
            // already update what is shown here, without waiting for the info-broadcast change (as this might not come when the client did not request these infos)
            this.eH.raise('roomInfoChange');

            let message = {
                roomName: this.name,
                arg: 'returnWritingTicket'
            };
            
            // send the note
            this.wsHandler.emitNote('room', message);
        }
    }

    /**
     * Try to get a writing ticket after the conenction has been established without
     */
    requestWritingTicket(){
        // we assume that the client at least now would like to have writingRights:
        this.writingWanted = true;

        // check if the client does not have writing rights yet and that we are connected 
        if (!this.writingTicketID && this.connected){
            
            // successHandler
            let succ = (data)=>{
                if (data.writingTicketID){
                    this.setWritingTicketID(data.writingTicketID);
                    this.eH.raise('roomInfoChange');
                }
            }

            // failureHandler
            let fail = ()=>{
                // dont care so far...
            }

            // request:
            let req = {
                roomName: this.name,
                arg: 'requestWritingTicket'
            };

            this.wsHandler.emitRequest('room', req, succ, fail);

        }

    }

    /**
     * Set the name of the client. Change only when the name is different (or when override=true, which is actually there only for the case, when the name changed during entering the room, as then the change would not yet have been sent and needs to be sent after getting connection). Send it to the server when already connected. 
     * @param {string} name 
     * @param {boolean} override Actually only used in above mentioned case!
     */
    setClientName(name, override=false){
        if(this.clientName != name || override){
            this.clientName = name;

            // do not send the changed/set clientName before we are connected to the room!
            if (this.connected){
                let sendData = {arg:'changeClientName', roomName: this.name, opt: name};
                this.wsHandler.emitRequest("room", sendData, ()=>{}, ()=>{}) // we actually do not care whether the message has arrived or not and thus we could also use emitNoteAck.
            }
            
        }
    }

    /**
     * set the writing ticket ID and also store it to the localStorage
     * @param {string} id The writing ticket ID
     */
    setWritingTicketID(id){
        this.writingTicketID = id;
        if ('localStorage' in window){
            let key = this.name + "writingTicketID"
            window.localStorage.setItem(key, id);
        }
        // report change of writingTicket to connected Vues and the room 
        this.vues.forEach(el=>el.onWritingTicketChange()) // vues
        this.onWritingTicketChange(); // room
    }

    onWritingTicketChange(){
        // nothing to do here, but maybe the inheriting class wants to override this function that is called everytime when setWritingTicketID is called here
    }

    afterFullreload(){
        //  in general, we call the same event on every connected vue-instance; the inheriting class might override this
        for (let v of this.vues){
            v.afterFullreload();
        }
    }

    deleteWritingTicketID(){
        // the function might also be called when there was no writing ticket before
        if (this.writingTicketID){
            this.writingTicketID = false;
            if ('localStorage' in window){
                let key = this.name + "writingTicketID"
                window.localStorage.removeItem(key);
            }
            // report change of writingTicket to connected Vues and the room 
            this.vues.forEach(el=>el.onWritingTicketChange()) // vues
            this.onWritingTicketChange(); // room
        }
    }

    /**
     * revoke the writingTicket of the client with the given sidhash. 
     * @param {} sidHash 
     */
    revokeWritingTicket(sidHash){

        let data = {
            roomName: this.name,
            arg: 'revokeWritingTicket',
            opt:{
                writingRequested: (this.writingWanted && !(this.writingTicketID)), // if we already have a writingTicket, we do not need another one...
                sidHash: sidHash
            }
        }

        if (this.writingWanted && !(this.writingTicketID)){
            // revoke the ticket and get it for this client --> on success, store the returned writingTicket for this room
            this.wsHandler.emitRequest('room', data, (data)=>{
                if (data.writingTicketID){
                    this.setWritingTicketID(data.writingTicketID);
                    // let Vue redraw everything
                    this.eH.raise('roomInfoChange');
                }
            }, (data, errCode)=>{
                // there was an error somewhere...
                // we dont care here... 
            });

        }else{
            // just revoke the ticket of sidHash, but do not gather a ticket; nothing todo when the answer arrives
            this.wsHandler.emitRequest('room', data, ()=>{}, ()=>{});
        }
    }

    /**
     * 
     * @param {*} success 
     * @param {*} failure 
     */
    getFullData(success=()=>{}, failure=(msg, code)=>{}){

        let text = 'getFullData:'; // string for output

        // TODO: make sure first that we are connected!!!

        // request the full data!
        this.wsHandler.emitRequest('room', {
            roomName: this.name,
            arg: 'fullData',
            opt: {}
        }, (data)=>{
            this.ID = data.ID
            this.data = data.data;
            
            if (data.writingTicketID){
                this.setWritingTicketID(data.writingTicketID);
                text += " got writingTicktID " + data.writingTicketID;
            }
            if (data.infos){
                this.infos = data.infos;
                // eventually we need to raise an event here that is listened by the room manager
                this.eH.raise('roomInfoChange');
            }

            logger.log(99, text)

            // call this function, as the client has to put the new data into the vue instance, such that it can observe the new data
            this.afterFullreload();

            // todo: eventually raise an event as well.

            success();

        }, (msg, code)=>{
            logger.log(3, "Could not get the full data for some strange reason. Code: " + code + " , message: " + msg)
            
            // call the failure callback
            failure(msg, code);
        });
    }

    /**
     * 
     * @param {*} change 
     */
    incomingChange(change){

        // see if the function exists
        if (change.funcName in this.functions){
            // check if the ID is newer than the current ID. This is needed since by default also the requesting client receives the broadcast; however the response should arrive earlier than the broadcast (for async reasons I'm/it'is not 100% sure that is true)
            // call the function
            if (this.ID!=change.ID){
                this.functions[change.funcName](change.data);
                // change the current ID
                this.ID = change.ID;
            } else {
                logger.log(98, `Incoming change (${JSON.stringify(change)}) was applied already before (i.e. this.ID=change.ID). The incoming change is ignored.`)
            }
        } else {

            logger.log(35, "Incoming change for function '" + change.funcName + "', which does not exist. Do full reload.")

            // full reload
            this.getFullData();
        }
    }


    /**
     * update the infos about other (connected) clients
     * @param {object} opt The transmitted infos
     */
    infoUpdate(opt){
        // only if the clients are really transferred
        if (opt.clients && opt.clients!=null){
            this.infos.clients = opt.clients;
        }
        this.infos.numClients = opt.numClients;
        this.infos.numClientsWriting = opt.numClientsWriting;
        this.infos.maxWritingTickets = opt.maxWritingTickets;

        // check if there are free writing tickets now and try to get one when the client does not have and would like writing rights
        // FUTURE: eventually do not automatically get a writing ticket or let a variable decide, what is done (nothing/inform user about free ticket/automatically request the ticket)
        if (!this.writingTicketID && this.writingWanted && opt.numClientsWriting < opt.maxWritingTickets){
            this.requestWritingTicket();
        }

        this.eH.raise('roomInfoChange');
    }

    /**
     * add a function that is then callable for messages from the server (either the result of a request or the broadcast following a request by another client)
     * TODO: all the rights stuff is NOT yet implemented
     * @param {string} name The name of the function. 
     * @param {function} func The actual function. The "this" object will be bound to that function. 
     */
    _addFunction(name, func){

        // IMPORTANT: do not forget to bind the function to this!
        this.functions[name] = func.bind(this);

    }

    /**
     * 
     * @param {string} funcName The functionName to call
     * @param {object} data The data to send to the respective function on the server. 
     * @param {object} functionOverride Define a function that is called instead of the usual func with the answer of teh server (if needed, defaults to undefined) with the data from the server. If not defined, the usual function si called. The function override is helpful when something else shall be done than what is defined in the usual execution function. Also this is helpful when the data passed to the change-requesting-client shall be different than what is sent in the broadcast.
     * @param {*} funcRollback The function to be called to rollback the change (e.g. delete a new entry in the data.)
     * @param {any} info Some information about the change. Might be useful in the future, as soon as there is a conflict handling.   
     */
    addToStack(funcName, data, functionOverride=undefined, funcRollback=()=>{}, info={}){

        let l = this.stack.length;

        // check whether we should try to write or not when onlineOnly=true 
        // this implementation where also the local stack must be empty is even stronger than what "onlineOnly" would mean alone, as it also makey sure that no stack builds up. Which would increase the chance that two clients have requests to the server at the same time.
        if (this.onlineOnly && (!this.connected || l>0)){
            window.alert("There is no connection to the server OR there is another request going on and thus requests/changes are not possible currently. "); // TODO: translation! --> ideally via a div-html-Element that is shown when the alert is raised. This way the alert can be translated in the usual way via ejs and i18n.
            return false;
        }

        // like this the server and also the clients can process the change
        let request = {func: funcName, data: data}

        // add an element to the stack
        this.stack.push({request: request, functionOverride: functionOverride, funcRollback: funcRollback, info:info})

        // if the stack was empty, start now the syncing
        if (l==0){
            this.sync();
        }
    }

    // try to send the next item to the server
    sync(){
        if (this.wsHandler.connected && this.dataSent==false){

            // get the request to send 
            let request = this.stack[0].request;

            // add the current ID
            request.ID = this.ID
            
            // data is currently on the way...
            this.dataSent = true;

            // create the object to send, such that it can be prcessed by the 'requestHandling' function
            let sendData = {arg:'function', roomName: this.name, opt: request};
            this.wsHandler.emitRequest("room", sendData, (data)=>{
                // currently no change is on the way anymore:
                this.dataSent = false;

                // change the (UU)ID as given by the server (if given: requests without writing stuff wont necessarily have an ID and certainly no new ID)
                if ('ID' in data){
                    this.ID = data.ID;
                }

                // delete the processed change (= first element) from the stack:
                let stackEl = this.stack.shift();

                // process the change --> call the respective function with the given data form the server and the client as arguments
                // when the overrideFunciton is given, call it. Otherwise use the same function as is called on any client receiving the change as broadcast.
                if (stackEl.functionOverride){
                    stackEl.functionOverride(data.data);
                } else{
                    this.functions[request.func](data.data);
                }

                if (this.stack.length>0){
                    this.sync()
                }
            }, (errMsg, errCode, status, lastIncomingAckCount)=>{
                // on failure: 
                // actually, what can we do on failure? Differentiate two cases: 
                //  1) The connection is lost --> wait for reconnect event
                //  2) There was an error during processing on the server --> undo/rollback all changes on the client (in the future: conflict handling)

                // TODO: we do not cover here the case when the request simply takes too long.

                if (errCode==1){
                    // response timed out, e.g. no answer during the total time of all attempts
                    logger.log(8, "Error while sending a change to server. Code: " + errCode + " , Msg: " + errMsg);

                    // TODO: eventually we should make this more flexible: either do rollback the full (!) stack or just try again later ..? 
                    // never only do rollback the last change, since other changes might be dependent on it

                    // TODO: note the user
                    this.rM.show

                    this.fullStackRollback()

                } else if (errCode <= 10){
                    // connection error --> wait for reconnect and then start syncing again
                    // TODO: the behavior 
                    logger.log(8, "Error while sending a change to server. Code: " + errCode + " , Msg: " + errMsg + ". Waiting for reconnect and then syncing again.");
                    
                    // do not delete the sent element form the stack, but reset the dataSent-status 
                    this.dataSent = false;
                    
                    // start syncing again when the connection was reestablished and the tabId reported
                    eH.eventSubscribe('tabIdSet', ()=>{this.sync();})

                } else {
                    // error on processing; e.g. because of conflicting changes
                    this.dataSent = false;

                    logger.log(8, "Error while sending a change to server. Code: " + errCode + " , Msg: " + errMsg + ". Rolling back the changes since and including the failed change. ");

                    if (errCode==13) { // 13=outdated --> start full reload
                        this.getFullData();
                    } else {
                        // TODO: show a message to the user!

                        //rollback
                        this.fullStackRollback();
                    }

                }

                // reset the stack on error and when onlineOnly=true
                if (this.onlineOnly){
                    this.stack = [];
                }
                

            }, 0, 1000) // do NOT retry (every 1000ms) (if we plan that retrys should be possible, we should implement it in the error handling; e.g. when the error is on the server, it makes never sense to retry.)
        }
        
    }

    /**
     * Rollback of the full stack, starting with the last entry. Only call this function, when no changes are beeing processed on the server.
     */
    fullStackRollback(){
        let el;
        while (el=this.stack.pop()){
            el.funcRollback();
        }
        this.dataSent = false;
    }

    /**
     * Register/link a new vue to this room
     * @param {roomClientVue} vue 
     */
    registerVue(vue){
        this.vues.push(vue);
    }

    /**
     * Unregister the view. To be done when the pageHandler changes the page or when a different page is loaded through http
     * @param {roomClientVue} vue 
     */
    unregisterVue(vue){
        let i = this.vues.indexOf(vue);
        if (i>=0){
            this.vues.splice(i,1);
        }
    }

    wsNoteIncoming(arg, opt){
        if (arg=='function'){
			logger.log(99, "Incoming change: " + opt)

			this.incomingChange(opt);

		} else if (arg == 'infoUpdate'){
			this.infoUpdate(opt)

		} else if (arg == 'fullData'){
            this.ID = opt.ID;
            // transfer the data element by element, such that "change-events" are raised on the properties and vue can react
            this.propertyTransfer(opt.data, this.data)
			
		} else if (arg == 'IDchange'){
			// only update the current ID, e.g. when a change occureds on the server, which has no effect on the dataset on the client
			this.ID = opt;
		} else {
			logger.log(5, "unknown arg-value ('" + arg + "') in room-note.");
		}
    }



    /**
     * returns the index and the object itself of the first object where the property prop is equal to value 
     * @param {array of objects} arr the array
     * @param {string} prop the property to look for
     * @param {*} val the value the property should have
     */
    findObjInArrayByProp(arr, prop, val){
        for (let i=0; i<arr.length;i++){
            if (arr[i][prop] == val){
                return [i, arr[i]];
            }
        }
        return [-1, {}];
    }

        /**
     * Transfer the values of the properties in objFrom to the properties in objTo. Recursive. 
     * If updateOnly=false (default), then properties that do exist only in objTo will be deleted. 
     * @param {object or array} objFrom 
     * @param {object or array} objTo 
     * @param {boolean} updateOnly If true, properties in objTo are not deleted when they do not exist in objFrom. Default: false 
     */
    propertyTransfer(objFrom, objTo, updateOnly=false){

        if (Array.isArray(objFrom)){

            if (!Array.isArray(objTo)){
                console.log('objTo was not of type array, but objFrom was. The property transfer would fail and thus is aborted.')
                return
            }

            // use pop and push to alter the length of the array. Note that we do not detect moved elements. We rather delete or add elements at the end and just transfer the values at each position. (Push is actually not needed, since assigning to elements outside the range is possible.)
            while (objTo.length>objFrom.length){
                objTo.pop();
            }
            /*
            let l = objTo.length; 
            for (let i=0;i<l-objFrom.length;i++){
                // delete the last elements
                objTo.pop();
            }*/

            // copy the elements
            for (let i=0;i<objFrom.length;i++){
                // pay attention to objects and arrays --> recursive calls needed
                if (typeof(objFrom[i])=='object'){
                    if (typeof(objTo[i])!='object'){
                        // if this is not done here and if objTo[i] is just a property, the recursive call on propertyTransfer will not occur byReference, as it must be to work.
                        if (Array.isArray(objFrom[i])){
                            objTo[i] = [];
                        } else {
                            objTo[i] = {};
                        }
                    } else {
                        // is it of the same type? otherwise reset the element in objTo
                        if (Array.isArray(objTo[i]) && !Array.isArray(objFrom[i])){
                            objTo[i] = {};
                        } else if (!Array.isArray(objTo[i]) && Array.isArray(objFrom[i])){
                            objTo[i] = [];
                        }
                    }
                    this.propertyTransfer(objFrom[i], objTo[i], updateOnly);
                } else {
                    objTo[i] = objFrom[i];
                }
            }
            
        } else {

            if (Array.isArray(objTo)){
                console.log('objTo was of type array, but should be a normal object as objFrom. The property transfer would fail and thus is aborted.')
                return
            }

            // is a regular object
            // copy new to objTo
            for (let prop in objFrom){
                if (typeof(objFrom[prop])=='object'){

                    if (!(prop in objTo)){
                        if (Array.isArray(objFrom[prop])){
                            objTo[prop] = [];
                        } else {
                            objTo[prop] = {};
                        }
                    } else {
                        // is it of the same type? otherwise reset the property in objTo
                        if ((typeof(objTo[prop])!='object' || Array.isArray(objTo[prop])) && !Array.isArray(objFrom[prop])){
                            objTo[prop] = {};
                        } else if ((typeof(objTo[prop])!='object' || !Array.isArray(objTo[prop])) && Array.isArray(objFrom[prop])){
                            objTo[prop] = [];
                        }
                    }
                    // transfer the property
                    this.propertyTransfer(objFrom[prop], objTo[prop], updateOnly);
                } else {
                    // just copy from/to
                    objTo[prop] = objFrom[prop];
                }
            }
            // delete all properties in objTo, which are not present in objFrom
            if (!updateOnly){
                for (let prop in objTo){
                    if (!(prop in objFrom)){
                        delete objTo[prop];
                    }
                }
            }
        }


    }

    /**
     * Test functions for the propprty transfer
     */
    propertyTransferTest(){
        // each call either with/out delete

        // object on top level
        let from = {};
        let to = {};
        from = {hello:'world', 12:27, nestedArr: ['no', 'worries', ['another', 'one'], 54, {}], nestedObj: {doesIt: 'work?', b: true}, propWrongAvail1:{test:1}, propWrongAvail2:{test:2}, propWrongAvail3:[12,13], propWrongAvail4:[14,15]};
        to = {propWrongAvail1:1, propWrongAvail2:['array instead of object'], propWrongAvail3:3, propWrongAvail4:{obj:'instead of array'}, doesnt:'exist in from'};
        this.propertyTransfer(from, to, false);
        console.log(from, to); // result should be to=from (however, as there is a different sort order, the json stringify doesnt work)
        console.log(JSON.stringify(from)==JSON.stringify(to))
        from = {hello:'world', 12:27, nestedArr: ['no', 'worries', ['another', 'one'], 54, {}], nestedObj: {doesIt: 'work?', b: true}, propWrongAvail1:{test:1}, propWrongAvail2:{test:2}, propWrongAvail3:[12,13], propWrongAvail4:[14,15]};
        to = {propWrongAvail1:1, propWrongAvail2:['array instead of object'], propWrongAvail3:3, propWrongAvail4:{obj:'instead of array'}, doesnt:'exist in from'};
        this.propertyTransfer(from, to, true);
        console.log(from, to); // result should be to<>from
        console.log(JSON.stringify(from)==JSON.stringify(to))
        to = [1,2,3];
        from = {o:'changed'};
        this.propertyTransfer(from, to, false); 
        console.log(from, to); // result result in a console message and non working transfer
        console.log(JSON.stringify(from)==JSON.stringify(to))

        // this tests everything with objFrom=array:
        from = [['another', 'one'], 54, {o:'bject in array'}, {obj:'again'}, {some:'property'}, ['array']];
        to = [1,2,{o:'changed', to:'was already here'},4,['array instead of object'],{obj:'instead of array'},7, 8, 9,'the end'];
        this.propertyTransfer(from, to, false);
        console.log(from, to); // result should be to=from
        console.log(JSON.stringify(from)==JSON.stringify(to))
        from = [['another', 'one'], 54, {o:'bject in array'}, {obj:'again'}];
        to = [1,2,{o:'changed', to:'was already here'},4,5,6,7, 8,9,'the end'];
        this.propertyTransfer(from, to, true);
        console.log(from, to); // result should be to<>from
        console.log(JSON.stringify(from)==JSON.stringify(to))
        from = [1,2,3];
        to = {o:'changed'};
        this.propertyTransfer(from, to, false); 
        console.log(from, to); // result result in a console message and non working transfer
        console.log(JSON.stringify(from)==JSON.stringify(to))
        

    }

    uuidv4() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

}

/**
 * A class to be "instantiated" for each Vue-instance.
 * TODO: remove the automatic 'getRoom' stuff and storing "the" room in this.room. Make it more flexible to allow for multiple rooms, respectively delegate these decisions to the inheriting class of the roomClientVue.
 */
class roomClientVue{

    constructor(roomName, writing, storeInfos, path, className, datasetName=''){

        // getting a room must be async, since loading a new room requires dynamic importing of code, which is async!

        // get the room/startup the room (is async!)
        // (v, roomName, writing=false, storeInfos=true, path='', className='', datasetName='')
        rM.getRoom(this, roomName, writing, storeInfos, path, className, datasetName).then(room => {
            this.room = room;
            //this.roomData = room.data;

            // raise event that the room (and probably the data) is now present
        this.onRoomLinked();

        }).catch((err)=>{
            logger.log(2, `The vue could not get the requested room (${roomName}): ${err}`);
        })
    }

    onRoomLinked(){

    }

    onWritingTicketChange(){

    }

    afterFullreload(){

    }

    /**
     * dataArrived: Function called as soon as the data has arrived for the first time
     */
    dataArrived(){
        // raised as soon as the room has its data stored for the first time
        
    }
}