
/**
 * The room manager provides a frontend to show information about the status of the connection and the single rooms.
 */
class roomManager{
	
	// do we have a connection?
	// status of all active rooms (online, active or passive, )

	/**
	 * Constructor: construct a roomManager instance. 
	 * @param {string} indicatorID The name of the element, where the color shall indicate the status of the ws-connection and which is used to click on and show the roomManager-vues. The indicator element must call roomManagerInstance.data.wsWindowShown=true; on click! (default='', meaning, there is no indicator). There must be two css-classes 'connected' and 'disconnected' which are assigned then by the roomManager.
	 */
	constructor(indicatorID=''){

		// the room-indicator shown to the users
		this.indicatorID = indicatorID;
		// if there is an indicator, we modify it a little here and add a circle, to be used as a request-indicator (when somethign is requested from te server): 
		if (this.indicatorID){
			var el = document.getElementById(this.indicatorID);
			// all previoud content will be moved in div, which is a child of the indicatorElement. This is needed just to make sure that the positioning of the content is not static, so that the stacking order gets correct (e.g. circle behind text)
			var contentText = el.innerHTML;
			// remove the previous content (to add it later on in the child div)
			el.innerHTML = '';

			// I'd like to have a circle centered in the indicator, which is going left to right and back in the indicator
			el.classList.add('requestPendingContainer');
			
			// create the circle
			let circle = document.createElement('div');
			//circle.classList.add('requestPendingCircle'); // will be added via Vue
			el.prepend(circle);

			// add the actual content again (since it is further down it will be in front)
			let contentDiv = document.createElement('div');
			contentDiv.innerHTML = contentText;
			contentDiv.style = "position: absolute; width: 100%;" // some formatting to make sure the content is correctly on top of the circle and the centering still works
			el.append(contentDiv);
		}

		// the eventhandler (eH) and the websocketHandler (wsHandler) are gobal objects and thus do not need to be storen in here (and probably are not even used)

		let clientName;
		// get or create the name of the client
		if ('localStorage' in window){
			if (window.localStorage.clientName){
				clientName = window.localStorage.clientName
			}
		}
		// when still empty, create a new string
		if (!clientName) {
			clientName = this.randName(8);
		}
		
		// the data object; shared with the vue-instance (this is the reason why we need this stupid data object in the roomManager and we cannot simply have all those properties directly in the roomManager-class)
		this.data = {
			// general ws-connection stuff:
			clientName: clientName, 
			connected: '', // must be changed after the vue is initialized, thus is '' and not true or false
			connecting: false, // unused so far
			tabId: 0, // unused so far
			wsWindowShown: false,
			clientWindowShown: false,
			revokeWindowShown: false,
			revokeClient: undefined,
			// room connections:
			rooms:{ // TODO: remove; this is/was for testing only
				/*'athletes':{name:'athletes', writingTicketID:'a3ho4', writingRights: false, dataSent:false, infos:{numClients:3, numClientsWriting:1, numClientsMaxWriting:2}, connected:true},
				'otherRoom':{name:'otherRoom', writingTicketID:false, writingRights: false, dataSent:false, infos:{numClients:3, numClientsWriting:1, numClientsMaxWriting:1}, connected:false}*/
			},
			// properties for the list of connected clients in the specified/selected room:
			roomSelected:undefined,
			clientsLoaded: true,
			any: 0 // this variable is never used on the frontend, but is used to make Vue redraw everything on increasing it everytime we want to redraw
			/*,
			clients:[
				{name:'Peter Parker', connected:true, writingRights: false},
				{name:'Superman', connected:false, writingRights: true}
			]*/
		};

		// listen to "WSconnectionChanged" event
		eH.eventSubscribe("wsClosed", (connected)=>{
			this.data.connected = false;

		})

		// listen to sid reported
		eH.eventSubscribe("TabIdSet", (tabId)=>{
			// now we are connected and can send messages
			this.data.connected=true;
			this.data.tabId = tabId;
		});

		// some informational data (e.g. not the data itself) in a room changed. As vue cannot react to changes in an class-instance, we have to initiate the update thouth this workaround.
		eH.eventSubscribe("roomInfoChange",()=>{
			this.data.any += 1;
		})
		
		// Vue.js stuff
		this.vueRoomManager = new Vue({
			el:'#vueRoomsManager',
			data: this.data,
			computed :{
				clients: ()=>{
					return this.rooms[this.roomSelected].infos.clients;
				},
				requestPending: function(){ // on purpose not an arrow-function
					// boolean, set to true if in any room a request is open; false if not; 
					let requestPend = false;
					for (let roomKey in this.rooms){
						let room = this.rooms[roomKey];
						//if (room.stack.length>0){ // probably if we do it this way
						if (this.rooms[roomKey].stack.length>0){
							requestPend = true;
						}
					}

					// additional task: format the indicator, if available
					if (indicatorID){
						let el = document.getElementById(indicatorID);	
						if (requestPend){
							if (!el.classList.contains('requestPendingCircle')){
								el.classList.add('requestPendingCircle');
							}
							
						}else{
							if (el.classList.contains('requestPendingCircle')){
								//el.classList.remove('requestPendingCircle');
							}
						}
					}

					return requestPend;
				}
			},
			watch: {
				rooms: {
					deep:true, // also changes in nested data shall raise this watcher
					handler:function(rOld, rNew){
					// recompute the clients variable (actually just recalc everything, found no better way yet. Note: I think the problem lies in the dependency of clients from the variable roomSelected: only the variable 'roomSelected' is reactive and thus can provoke an update, but not changes in the infos.clients)
					this.$forceUpdate();
					console.log('roomChange')
					},
					immediate:true // false is the default I think
				},
				connected: (conNew, conOld)=>{
					// as the always shown element is outside the vueDiv, we have to set its background via javascript
					if (this.indicatorID){
						var el = document.getElementById(this.indicatorID);
						if (conNew) {
							if (el.classList.contains('disconnected')){
								el.classList.remove('disconnected');
							}
							el.classList.add('connected');
						} else {
							if (el.classList.contains('connected')){
								el.classList.remove('connected');
							}
							el.classList.add('disconnected');
						};
					}
				},
				
			},
			methods: {
				clientNameChanged : (event)=>{
					// store to localStorage
					if ('localStorage' in window){
						window.localStorage.setItem('clientName', this.data.clientName)
					}
					
					// report to roomServers
					for (let room in this.data.rooms){
						this.data.rooms[room].setClientName(this.data.clientName);
					}
					
				},
				revokeWritingTicket: (sidHash)=>{
					// revoke the writing ticket for the selected client (all the rest will be done in roomClient)
					this.data.rooms[this.data.roomSelected].revokeWritingTicket(sidHash);
				},
				revokeClientClick:(client)=>{
					if (client.writing && !(client.connected) ){
						this.data.revokeClient = client.sidHash; 
						this.data.revokeWindowShown = true;
					} 
				}

			}
	
			});


		// initially set the status of the wsConnection:
		// NOTE: do not move this before setting vueRoomManager, because we need to raise the connected-watcher!
		this.data.connected = wsHandler.connected;

		//this.data.clientWindowShown = true;

		//document.getElementById('wsWindow').classList.remove('wsWindowHidden');

	}

	/**
	 * create a random name for the client (if it was not set before)
	 * @param {integer} length 
	 */
	randName(length) {
		var result           = '';
		var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		var charactersLength = characters.length;
		for ( var i = 0; i < length; i++ ) {
		   result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	}

	/**
	 * Show or hide the wsRooms window
	 */
	/*toggleWsRooms() {
		if (this.data.wsWindowShown){
			this.data.wsWindowShown = false;

		}
	}*/

	/**
	 * 
	 * @param {roomClient-object} room 
	 */
	registerRoom(room){

		// TODO: when te same room was added twice (e.g. because two shown parts of the window wanted to open its own, identical rooms, then the latter would overwrite the first)
		// --> thus we need to rethink the starting of rooms and how they are linked to data!
		// --> a room should probably NOT handle the vue, but only process the data, such that multiple Vue's could be connected to the same data.
		
		// put the room into the data structure
		this.data.rooms[room.name] = room;

		// let the room know the name of the client and report it to the server
		// we cannot do that here yet when the sid was not reported yet TODO
		room.setClientName(this.data.clientName);
	}

	// TODO: shall vue-instances and other code blocks really request writing and storeInfos or should this always be defined by the room/vue itself?
	// if the the vue-instances do decide, then we need to register them appropriately, such that if one instance requires writing and the other not, we can return the wirting ticket as soon as the writing-instance leaves the room. 
	/**
	 * returns the reqeusted room. if the room is not connected, it tries to connect.  
	 * @param {roomClientVue} v The instance of the room client view that wants to
	 * @param {*} roomName 
	 * @param {*} writing 
	 * @param {*} storeInfos 
	 * @param {string} path If path is given, the room will automatically be loaded from that path if it does not already exist. Should be an absolute path, as otherwise it is reqlative to the page we currently are in! i.e. '//localhost/filename.js'
	 * @param {string} className The class-name of the room-client-class. If not given, it is taken the same as the room-name
	 * @param {string} datasetName The name of the requested dataset; by default='' (room data)
	 * @returns returns the room. Please note that the requests made for 'writing' and 'storeInfos' are probably not set appropriately  
	 */
	async getRoom(v, roomName, writing=false, storeInfos=true, path='', className='', datasetName=''){
		let room;
		if (roomName in this.data.rooms){
			room =  this.data.rooms[roomName];

			// register roomClientVue in the room
			room.registerVue(v);

		} else {
			// try to load the room
			if (path){
				// should work without rM room = await this.loadRoom(v, path, roomName, className, rM)//.catch((err)=>{`The room could not be loaded: ${err}`});
				room = await this.loadRoom(v, path, roomName, className, writing, storeInfos, datasetName)//.catch((err)=>{`The room could not be loaded: ${err}`});
				//room = this.data.rooms[roomName];
				
			} else {
				throw new Error ('Room does not exist and no path is given.');
			}
		}

		if (room.connected){
			// check if writing and storeInfos are "correct"
			if (writing && !(room.writingWanted)){
				room.requestWritingTicket();
			}

			// TODO: check storeInfos and request if required! (currently would need leave and reconnect!)

		} else {
			// NOTE: we might end up here not only when the room is new, but also when we simply have no connection!

			// set writing and storeInfos
			if (writing){ // the if ensures that we do not change from write to non-write with an additional connected vue-instance.
				room.writingWanted = writing;
			}
			if (storeInfos){ // the if ensures that we do not change from write to non-write with an additional connected vue-instance.
				room.storeInfos = storeInfos;
			}

			// try to connect
			room.connect(writing, ()=>{
				// success
			}, (msg, code)=>{
				// failure

				if (code==123){
					// try to connect without writing rights
					room.connect(false, ()=>{}, (msg, code)=>{
						throw new Error();
					});
				}
			})
			
		}

		return room;
	}

	/**
	 * 
	 * @param {*} roomName 
	 * @param {*} viewName 
	 * @param {*} writing 
	 * @param {*} storeInfos 
	 * @param {string} path If path is given, the room will automatically be loaded from that path if it does not already exist. 
	 */
	async getView(roomName, viewName, writing, storeInfos, path=''){
		// TODO
	}

	/**
	 * Load a room, but od not yet connect it; This function does NOT check if the room does not already exist!
	 * @param {roomClientVue} v The view that finally shall be linked to the room
	 * @param {string} path Should be an absolute path, as otherwise it is reqlative to the page we currently are in! i.e. '//localhost/filename.js'
	 * @param {string} roomName The name of the room.
	 * @param {string} className The class-name of the room-client-class. If ='' or =False, it is taken the same as the room-name
	 * //@param {roomManager} rM
	 * @param {string} datasetName The name of the dataset that is called
	 * @throws Errors are thrown
	 * @returns The newly loaded room. It is NOT connected yet.
	 */
	async loadRoom(v, path, roomName, className,  writing, storeInfos, datasetName){

		// load the room from the path
		// Attention: dynamical imports as we do here are a pretty new (2019) feature. 
		return import(path).then((mods)=>{

			// default className
			if (!className){
				className = roomName;
			}

			// create the room, but do NOT connect it yet
			if (className in mods){
				
				// (v, wsHandler, eventHandler, rM, writing=false, storeInfos='', datasetName='')
				let room = new mods[className](v, wsHandler, eH, this, writing, storeInfos, datasetName); // rooms must not have any arguments apart of wsHandler and eventHandler

				// check if the new room has the same name as the given name; otherwise destroy the room again, do not add it to the rooms and return false
				if (room.name==roomName){
					
					this.data.rooms[roomName] = room;
					return room;

				} else {
					throw new Error('The property name of the room must be the roomName. Could not load the room.');
				}
			} else {
				throw new Error('The room does not exist in the module in the given path.');
			}
		})
	}

	/**
	 * Add a room such that its status are shown here:
	 * @param {string} name The name of the room; to be shown along with the status. Also used as identifier, thus MUST be unique!
	 * @param {bool} connected The connection status of the room: Is the client-room connected/registered to its conterpart on the server?
	 * @param {roomClient} room reference to the room instance
	 * @param {bool} writingRights does the client have writing rights
	 * @param {bool} writingWanted does the client want writing rights
	 * @param {bool} dataSent is currently some data transferred?
	 * @param {numeric} numClients how many clients are connected
	 * @param {numeric} numClientsWriting optional (mandatory when writingWanted): how many clients have writing rights
	 * @param {numeric} numClientsMaxWriting optional (mandatory when writingWanted): how many clients can at maximum have writing rights
	 */
	registerRoomOld(name, connected, room, writingRights, writingWanted, dataSent, numClients, numClientsWriting=0, numClientsMaxWriting=0){
		// TODO: think about: where do we want to implement the logic for setting the user information? Only in this class or do we simply give every room a referecnce to an object and this room then shall put all its information in there, through which it will get updated automatically? Its smarter to have the whole logic in this class and that room do not have to care, how we tell Vue.js the necessary information. So it is possible to change somethign on the Vue.js implementation of the status page without having to change the respective stuff in every room. 
		// Idea: we do not give each room simply an object reference, where it has to change the structre itself, but we give it specific functions to call when it wants to change 

		var index = this.info.rooms.push({}); // add an empty obeject
		this.data.rooms[name] = {
			name: name,
			connected: connected,
			room: room, // this is actually not needed for vue, but I hope that vue can handle non-json objects too; otherwise create an extra variable for the room-instances
			writingRights: writingRights,
			writingWanted: writingWanted,
			dataSent: dataSent,
			numClients: numClients,
			numClientsWriting: numClientsWriting,
			numClientsMaxWriting: numClientsMaxWriting
		}

		// old stuff; done differently now
		/*// create the object to return, storing all the functions to call on changes in the room. (This is needed because we cannot return multiple arguments. )
		var ret = {};
		
		ret.connectedChanged = (connceted)=>{
			roomInfo.connceted = connected;
		};

		// act on changes in the array of Blocking and non-blocking changes
		ret.stackNonBlockingChanged = (stack)=>{
			// TODO: do something with the stack; at least count the items
		};
		ret.stackBlockingChanged = (stack) =>{
			// TODO: do something with the stack; at least count the items
		};

		// TODO: need some more functions, e.g. for conflict handling

		return ret;*/
	}

	/**
	 * Deletes the room from the list of rooms. 
	 * @param {string} name The name of the room. (is used as identifier; must be unique)
	 */
	deleteRoom(name){
		try {
			delete this.data.rooms[name];
		}catch (ex) {

		}
	}

	/**
	 * Called by the ws-note-handler if a change for a room is incoming
	 * @param {object} data An object with properties "arg", "roomName" and eventually "opt"
	 */
	wsNoteIncoming(data){
		/* data: {
			roomName:'roomXY',
			arg: 'function',
			opt: {}
		}*/

		// data must have the following arguments: arg, roomName, opt (optional)
		if (!('arg' in data && 'roomName' in data)){
			logger.log(5, "The received room-note (" + JSON.stringify(data) + ") has no 'arg' and/or 'roomName' property!")
			return;
		}
		if (!(data.roomName in this.data.rooms)){
			logger.log(5, "The room '" + data.roomName + "' does not exist.");
			return;
		}

		// everything ok
		// get room
		let room = this.data.rooms[data.roomName];

		// let the room do the rest
		let opt = data.opt ?? {};
		room.wsNoteIncoming(data.arg, opt)
		
	}

}
