//alabusTest

var https = require('https');
var fs = require('fs')

// something completely different: get Data from alabus! Works so far!
var options = {
	host: 'alabus.swiss-athletics.ch',
	port: 443,
	path: '/rest/License/Athletica/ExportStammDataFull',
	//method: 'GET', // not necessary when https.get is used
	headers: {
		authorization: "Basic " + Buffer.from("121832:struppi1").toString('base64'),// base64(username:pw)}
		connection: 'close'
	}
} 

/*
fs.writeFile('message.txt', 'Hello Node', function (err) {
	if (err) throw err;
	console.log('It\'s saved!');
  });
*/


https.get(options, function(res) {	
	/*console.log('STATUS: ' + res.statusCode);
	console.log('HEADERS: ' + JSON.stringify(res.headers));*/
	res.setEncoding('binary');

	// put together the data
	var data = "";
	res.on('data', function (chunk) {
		data += chunk;
	  //console.log('BODY: ' + chunk);
	});

	// write to disk (or TODO: process further)
	res.on('end', ()=>{
		setTimeout(()=>{
        // unGzip and write to disk
        
        // write gzip
		fs.writeFile("Stammdaten.gz", data, encoding="binary",(err)=>{console.log(err);}) // stores the file 
        // funktioniert bis dahin!
				// jetzt noch ent-gzippen und einlesen...
				
				//  use zlib for decompression

		},1000)
	})

  }).on('error', function(e) {
	console.log("Got error: " + e.message);
  });