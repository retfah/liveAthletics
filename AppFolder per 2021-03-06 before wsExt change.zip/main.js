import test from './imp.mjs';
console.log('test')
const http = require('http');
test()